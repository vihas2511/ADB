#!/usr/bin/env bash
curl -sL https://iiot-services.pg.com/InstallIiotCertsDeb | sudo bash

pip install certifi