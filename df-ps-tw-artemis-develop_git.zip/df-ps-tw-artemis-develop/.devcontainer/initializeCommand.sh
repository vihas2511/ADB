#!/bin/bash
mkdir -p $HOME$USERPROFILE/.ssh
touch $HOME$USERPROFILE/.databrickscfg
mkdir -p $HOME$USERPROFILE/.config/pypoetry