# Operations

## Key Contacts
* Product Owner:
* Dev team(L3 support):

## Azure Resources Used
### Dev
* Databricks workspace: `dbrproductsupplyn101`
* Azure Subscription: `PG-NA-External-Prod-04`
* Azure Resource group: `AZ-RG-ProductSupply-Non-Prod-01`
* Azure storage account: `dnproductsupplyx61f18904`
* Azure storage container: `<container_name>`
* service principal: `Az-App-CDL-ProductSupply-NonProd`
* Keyvault: `kv-prodsupply-non-prod`

### Prod
* Databricks workspace: `dbrproductsupplyp201`
* Azure Subscription: `PG-NA-External-Prod-04`
* Azure Resource group: `AZ-RG-ProductSupply-Prod-01`
* Azure storage account: `dpproductsupplyx842d2049`
* Azure storage container: `<container_name>`
* service principal: `AZ-App-CDL-ProductSupply`
* Keyvault: `kv-prodsupply-prod`

### PSDH
* databricks workspace for Product Supply Data HUB: `psdatabricksprodusers`

## Regularly Scheduled Maintenance
### Changing passwords/tokens
If the password/token expires, please create a new one and upload it in Azure KeyVault. 
> Note that there are no pipeline-speciffic secrets for this application.

## Common Problems & Solutions
### Fail scenario
After workflow failure an email is sent to the defined group(s). The list of emails addresses is set up in the databricks asset bundle [job definition](/resources/idelist_pipeline_job.yml) There is no need to remove any data before the restart. You can simply rerun the process from where it failed.

For CDL publication issues contact DDAPI support (applies only to `publish_task` of the pipeline).
