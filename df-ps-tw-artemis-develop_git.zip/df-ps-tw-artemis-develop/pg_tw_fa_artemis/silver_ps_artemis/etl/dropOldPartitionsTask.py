import logging
import sys
import time
from datetime import datetime

import pyspark.sql.functions as f
from pg_composite_pipelines_configuration.configuration import Configuration

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def drop_local_partition(logger, spark, table_name, part_spec):
    """Drops old partitions (older than x months) in a local managed table."""
    logger.info("Dropping partition {} in table {}".format(part_spec, table_name))
    drop_partition = f"""
        DELETE FROM {table_name} 
            WHERE {part_spec}
        """
    run = spark.sql(drop_partition)
    # Optimize the droped Partition
    spark.sql(f"OPTIMIZE {table_name} WHERE {part_spec}")

    logger.info(
        "The {} partition in table {} has been dropped".format(part_spec, table_name)
    )
    return 0


def drop_old_partitions(logger, spark, table_name, retention):
    """Drops old partitions (older than x months).
    Assumption: table is partitioned only on a one column, which has format YYYYMM"""

    logger.info(
        "Dropping older partitions than {} months in a table: {}".format(
            retention, table_name
        )
    )
    query = f"""
            DESCRIBE EXTENDED {table_name}
            """
    table_desc_df = spark.sql(query)

    table_type = (
        table_desc_df.where("col_name = 'Type'").select("data_type").collect()[0][0]
    )

    # Get the location from a table description
    dbfs_table_location_path_tmp = (
        table_desc_df.where("col_name = 'Location'").select("data_type").collect()[0][0]
    )

    # Replace the beginning of the path, because we will use shell, not the DB dbutils library
    dbfs_table_location_path = dbfs_table_location_path_tmp.replace("dbfs:/", "/dbfs/")

    current_year_mth = int(time.strftime("%Y%m"))
    show_part = f"""show partitions {table_name}"""
    # Get table partitions with columns
    partitions_2_drop_df = (
        spark.sql(show_part)
        .withColumnRenamed("cal_year_mth_num", "partition_path")
        .withColumn(
            "partition_spec",
            f.concat(
                f.lit("cal_year_mth_num='"),
                f.substring_index(f.col("partition_path"), "=", -1),
                f.lit("'"),
            ),
        )
        .withColumn(
            "deapest_subpartition_spec",
            f.substring_index(f.col("partition_path"), "/", -1),
        )
        .withColumn(
            "deapest_subpartition_value",
            f.substring_index(f.col("deapest_subpartition_spec"), "=", -1),
        )
        .withColumn(
            "deapest_subpartition_date",
            f.last_day(f.to_date(f.col("deapest_subpartition_value"), "yyyyMM")),
        )
        .withColumn("retention_date", f.add_months(f.current_date(), (-1) * retention))
        .withColumn(
            "drop_partition_flag",
            f.when(
                f.col("deapest_subpartition_date") < f.col("retention_date"), "Y"
            ).otherwise("N"),
        )
        .where("drop_partition_flag = 'Y'")
    )

    for partition in partitions_2_drop_df.collect():
        part_spec = partition.partition_spec
        drop_local_partition(logger, spark, table_name=table_name, part_spec=part_spec)

    logger.info("Dropping old partitions for {} has finished.".format(table_name))
    # Exit
    return 0


def main():
    """Main"""
    spark = get_spark()
    dbutils = get_dbutils()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    try:
        args = sys.argv

        tablename = args[1]

        retention = config["retention"]

        catalog, schema = config["catalog-name"], config["schema-name"]

        schema = f"{config['catalog-name']}.{config['schema-name']}"

        table_name = f"{schema}.{config['tables'][tablename]}"

        # Drop old partitions
        # if tablename != "shpmt_report_star":
        drop_old_partitions(logger, spark, table_name=table_name, retention=retention)

        logger.info("execution ended")

    except Exception as exception:
        error_desc = "exception: {} at {}".format(type(exception), datetime.now())
        print(error_desc)
        sys.stderr.write(error_desc)
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logger.error(exception)
        sys.stdout.flush()
        sys.exit(1)


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
