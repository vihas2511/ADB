import logging
import sys
from datetime import datetime

from dateutil.relativedelta import relativedelta
from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import DataType, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def insertshpmtaltuomsfct(
    spark,
    logger,
    run_year_mnt,
    region,
    regional_db_name,
    g11_db_name,
    target_db_name,
    target_table,
):

    change_type_code = (
        "sap_chng_type_code"
        if region == "N6P" and regional_db_name == "cdl_ps_prod.silver_sap_n6p_rt"
        else "simp_chng_type_code"
    )

    query = f"""
    SELECT {run_year_mnt}  AS cal_year_mth_num
        , sht.site_code 
        , sht.prod_id, sht.shpmt_alt_uom_qty, sht.shpmt_alt_uom
        , sht.base_uom
        , COALESCE(freight_type_code_1, freight_type_code_2, '#') AS freight_type_code
        , sht.dlvry_doc_num
        , sht.dlvry_item_num
        , sht.order_doc_type_code
        , sht.sold_to_customer_id 
        , '{region}' AS region_abbr_code
    FROM (SELECT shpmt.site_code
                , shpmt.prod_id
                , shpmt.shpmt_alt_uom_qty
                , shpmt.shpmt_alt_uom
                , shpmt.base_uom
                , ftl_1.freight_type_code AS freight_type_code_1
                , ftl_2.freight_type_code AS freight_type_code_2
                , shpmt.dlvry_doc_num
                , shpmt.dlvry_item_num
                , shpmt.order_doc_type_code
                , shpmt.sold_to_customer_id
            FROM (SELECT 
                        
                        CASE WHEN sdi.plant_id is NOT NULL then sdi.plant_id ELSE sps.plant_id END as site_code 
                        , sdi.prod_id, sdi.dlvry_sales_unit_qty as shpmt_alt_uom_qty, sdi.sales_uom  as shpmt_alt_uom
                        , prd.base_uom
                        , NVL(caff.affiliate_flag, '') AS affiliate_flag, substring(sdh.sap_box_name, 5,3) as sap_source_system_id 
                        
                        , CASE 
                            WHEN (sdh.actual_gi_date != '00000000' AND sdh.actual_gi_date RLIKE '[0-9]{{8}}')
                            THEN sdh.actual_gi_date 
                            WHEN (sdh.shpmt_start_date != '00000000' AND sdh.shpmt_start_date RLIKE '[0-9]{{8}}' AND sdh.shpmt_start_date != '00010101')  
                            THEN sdh.shpmt_start_date
                            WHEN (sdh.plan_gm_date != '00000000' AND sdh.plan_gm_date RLIKE '[0-9]{{8}}')
                            THEN sdh.plan_gm_date
                            ELSE null
                        END AS shpmnt_date
                        
                        , sdh.dlvry_doc_num
                        , sdi.dlvry_doc_item_num as dlvry_item_num
                        , soh.sales_doc_type_code as order_doc_type_code
                        , sdh.sold_to_customer_id
                    FROM (
                        
                        SELECT head.VBELN as dlvry_doc_num, head.MANDT as sap_client_id, head.sap_box_name, head.VSTEL as ship_recvng_point_code
                            , head.WADAT_IST as actual_gi_date, head.AEDAT as change_date
                            , head.WADAT as plan_gm_date, head.KUNAG as sold_to_customer_id, shpmt_hi.shpmt_start_date
                            , row_number() OVER (PARTITION BY head.VBELN, head.MANDT, head.sap_box_name
                                                    ORDER BY
                                                    IF(head.WADAT_IST NOT RLIKE '[0-9]{{8}}' OR isnull(head.WADAT_IST), '00000000', head.WADAT_IST) DESC,
                                                    IF(shpmt_hi.shpmt_start_date NOT RLIKE '[0-9]{{8}}' OR isnull(shpmt_hi.shpmt_start_date), '00000000', shpmt_hi.shpmt_start_date) DESC,
                                                    IF(head.WADAT NOT RLIKE '[0-9]{{8}}' OR isnull(head.WADAT), '00000000', head.WADAT) DESC)
                                            AS rn
                        FROM {regional_db_name}.likp head        
                        LEFT JOIN (
                            SELECT shpmt_h.DATBG as shpmt_start_date
                                , shpmt_h.sap_box_name
                                , shpmt_i.VBELN as bill_doc_num
                            FROM {regional_db_name}.vttk shpmt_h
                            JOIN {regional_db_name}.vttp shpmt_i
                            ON shpmt_h.TKNUM = shpmt_i.TKNUM
                            AND shpmt_h.sap_box_name = shpmt_i.sap_box_name
                            AND shpmt_h.{change_type_code} != 'D'
                            AND shpmt_i.{change_type_code} != 'D'	
                        ) shpmt_hi
                        ON shpmt_hi.bill_doc_num = head.VBELN
                        
                        WHERE 1=1
                            AND head.{change_type_code} != 'D'
                            AND (CAST(SUBSTR(head.WADAT_IST, 1,6) AS INT) = {run_year_mnt} 
                            OR CAST(SUBSTR(head.WADAT, 1,6) AS INT) = {run_year_mnt}
                            OR CAST(SUBSTR(shpmt_hi.shpmt_start_date, 1,6) AS INT) = {run_year_mnt})
                        ) sdh
            LEFT  JOIN (SELECT kna.KUNNR as customer_id
                                , CASE 
                                    WHEN kna.BEGRU LIKE 'AF%' 
                                    THEN 'X'
                                    ELSE '' 
                                END AS affiliate_flag
                            FROM {g11_db_name}.kna1 kna
                            WHERE kna.simp_chng_type_code != 'D'
                            ) caff
                    ON sdh.sold_to_customer_id = caff.customer_id
                    
                    JOIN (SELECT MATNR as prod_id, LFIMG as dlvry_sales_unit_qty ,
        VRKME as sales_uom ,POSNR as dlvry_doc_item_num ,
        VBELN as dlvry_doc_num,MANDT as sap_client_id ,sap_box_name,VGBEL as ref_doc_num,WERKS as plant_id,KOMKZ as pick_control_code 
        FROM
        {regional_db_name}.lips
        where       
        {change_type_code} not in ('D', 'I' ,'U', 'N' )
                        UNION         
        SELECT prod_id, dlvry_sales_unit_qty ,
        sales_uom ,dlvry_doc_item_num ,
        dlvry_doc_num,sap_client_id ,sap_box_name,ref_doc_num, plant_id,pick_control_code
        FROM
        (select MATNR as prod_id, LFIMG as dlvry_sales_unit_qty ,
        VRKME as sales_uom ,POSNR as dlvry_doc_item_num ,
        VBELN as dlvry_doc_num,MANDT as sap_client_id ,sap_box_name,VGBEL as ref_doc_num,WERKS as plant_id,KOMKZ as pick_control_code,
        row_number() over(partition by MATNR,POSNR,VBELN,MANDT,sap_box_name
        order by bd_mod_utc_time_stamp)as rr from
        {regional_db_name}.lips
        where
                    {change_type_code} in ('I', 'U', 'N'))where rr=1)sdi 
                    ON sdh.dlvry_doc_num = sdi.dlvry_doc_num
                    AND sdh.sap_client_id = sdi.sap_client_id 
                    AND sdh.sap_box_name = sdi.sap_box_name 
                    AND sdi.dlvry_sales_unit_qty IS NOT NULL
                    
                    AND sdh.rn = 1
                    AND sdi.pick_control_code IS NOT NULL
                    AND sdi.pick_control_code NOT IN ("", "null", " ")
                    
                    AND sdi.sales_uom IS NOT NULL
                    
                    JOIN (
                            SELECT mara.MATNR as prod_id,mara.MEINS as base_uom
                    FROM {g11_db_name}.mara mara
                    WHERE mara.MTART = 'FERT' 
                    AND mara.simp_chng_type_code not in ('I','U','D','N' ) 
    UNION 	
    SELECT prod_id,base_uom
                    from(SELECT mara.MATNR as prod_id,mara.MEINS as base_uom, ROW_NUMBER() over(partition by mara.MATNR order by mara.bd_mod_utc_time_stamp desc )as rnk
                                FROM {g11_db_name}.mara mara
                    where  mara.simp_chng_type_code in ('I','U','N' ) and mara.MTART = 'FERT' )
                    where rnk=1 	
                        ) prd
                    ON sdi.prod_id = prd.prod_id
                    JOIN (
                    SELECT soh_in.sales_doc_num, soh_in.sales_doc_type_code, soh_in.sap_client_id, soh_in.sap_box_name
                            FROM (select aa.sales_doc_num, aa.sales_doc_type_code, aa.sap_client_id, aa.sap_box_name 
                                from (SELECT VBELN as sales_doc_num, AUART as sales_doc_type_code, MANDT as sap_client_id, sap_box_name
                                        from {regional_db_name}.vbak
                                        WHERE {change_type_code} not in ('D', 'I' ,'U','N' )
                                        union
                                        select sales_doc_num, sales_doc_type_code, sap_client_id, sap_box_name from
                                        (SELECT A.VBELN as sales_doc_num, A.AUART as sales_doc_type_code, A.MANDT as sap_client_id, A.sap_box_name
                                            ,ROW_NUMBER() over(partition by A.VBELN, A.AUART, A.MANDT, A.sap_box_name order by                                                          
                                            A.bd_mod_utc_time_stamp desc)as rnk
                                            FROM {regional_db_name}.vbak A
                                            WHERE A.{change_type_code} in ('I', 'U', 'N') 
                                            )
                                            where rnk = 1) aa
                                    UNION ALL 
                                SELECT EBELN as sales_doc_num, BSART as sales_doc_type_code, MANDT as sap_client_id, sap_box_name 
                                    FROM {regional_db_name}.ekko
                                    WHERE 1=1
                                    AND {change_type_code} not in ('D', 'I' ,'U', 'N') 
                                    AND BSTYP = 'F'
                                    union
                                select sales_doc_num, sales_doc_type_code, sap_client_id, sap_box_name from
                                    (SELECT B.EBELN as sales_doc_num, B.BSART as sales_doc_type_code, B.MANDT as sap_client_id, B.sap_box_name 
                                    ,ROW_NUMBER() over(partition by B.EBELN, B.BSART ,B.MANDT, B.sap_box_name order by                                                                 
                                    B.bd_mod_utc_time_stamp desc)as rk
                                    FROM {regional_db_name}.ekko B
                                    WHERE 1=1
                                    AND B.{change_type_code} in ('I', 'U', 'N') 
                                    AND B.BSTYP = 'F'
                                        )
                                    where rk = 1 
                                ) soh_in 
                        ) soh
                    ON sdi.ref_doc_num = soh.sales_doc_num
                    AND sdi.sap_client_id = soh.sap_client_id 
                    AND sdi.sap_box_name = soh.sap_box_name 
                    JOIN (SELECT distinct order_type_code, sap_source_system_id
                            FROM {target_db_name}.freight_type_lkp
                        ) sd_doc_fil
                    ON soh.sales_doc_type_code = sd_doc_fil.order_type_code
                    AND substring(sdh.sap_box_name, 5,3) = sd_doc_fil.sap_source_system_id 
                LEFT JOIN (SELECT tvswz.VSTEL as ship_recvng_point_code
                                , tvswz.WERKS as plant_id
                                , ROW_NUMBER() OVER (PARTITION BY tvswz.VSTEL ORDER BY tvswz.WERKS) as rn
                            FROM {g11_db_name}.tvswz tvswz
                            WHERE tvswz.simp_chng_type_code != 'D'
                        )sps 
                    ON sdh.ship_recvng_point_code = sps.ship_recvng_point_code
                    AND sps.rn = 1
                ) shpmt
        LEFT JOIN {target_db_name}.freight_type_lkp ftl_1
            ON ftl_1.order_type_code = shpmt.order_doc_type_code
            AND ftl_1.site_code = shpmt.site_code
            AND ftl_1.sold_to_customer_id = shpmt.sold_to_customer_id
            AND nvl(ftl_1.sold_to_affiliate_flag, '') = shpmt.affiliate_flag
            AND ftl_1.sap_source_system_id = shpmt.sap_source_system_id
        LEFT JOIN {target_db_name}.freight_type_lkp ftl_2
            ON ftl_2.order_type_code = shpmt.order_doc_type_code
            AND ftl_2.site_code = '*'
            AND ftl_2.sold_to_customer_id = '*'
            AND nvl(ftl_2.sold_to_affiliate_flag, '') = shpmt.affiliate_flag
            AND ftl_2.sap_source_system_id = shpmt.sap_source_system_id
            WHERE CAST(SUBSTR(shpmt.shpmnt_date, 1,6) AS INT) = {run_year_mnt} 
        ) sht
    """

    shpmt_alt_uom_sfct = spark.sql(query)

    shpmt_alt_uom_sfct.write.format("delta").mode("overwrite").option(
        "replaceWhere", f"region_abbr_code = '{region}'"
    ).partitionBy("region_abbr_code").saveAsTable(f"{target_db_name}.{target_table}")

    logger.info(
        "{} regional data has been successfully loaded into {}.{}".format(
            region, target_db_name, target_table
        )
    )

    return 0


def main():

    spark = get_spark()
    dbutils = get_dbutils()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    args = sys.argv

    catalog, schema = config["catalog-name"], config["schema-name"]

    g11_db_name = f"{config['src-catalog-name']}.{config['g11_db_name']}"

    schema = f"{config['catalog-name']}.{config['schema-name']}"

    print(args)

    region = args[1]

    run_year_mnt = int(args[2])

    regional_db_name = (
        f"{config['src-catalog-name']}.{config['region-schema-name'][region]}"
    )

    target_table = f"{config['tables']['shpmt_alt_uom_sfct']}"

    insertshpmtaltuomsfct(
        spark=spark,
        logger=logger,
        run_year_mnt=run_year_mnt,
        region=region,
        regional_db_name=regional_db_name,
        g11_db_name=g11_db_name,
        target_db_name=schema,
        target_table=target_table,
    )


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
