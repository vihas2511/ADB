import logging

from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import DataType, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def insertShpmtSfct(spark, logger, target_db_name, target_table):

    # Initializing the Target table schema to avoid schema based conflicts

    tgt_schema = spark.table(f"{target_db_name}.{target_table}").schema

    query1 = f"""
		SELECT sh_buom.cal_year_mth_num
		, sh_buom.site_code
		, sh_buom.prod_id
		, sh_buom.base_uom
		, sh_buom.shpmt_buom_qty
		, IF(marm_su.prod_id IS NOT NULL, marm_su.buom_alt_uom_factor, 1) AS buom_su_factor
		, cast(cast(sh_buom.shpmt_buom_qty as double) * cast(IF(marm_su.prod_id IS NOT NULL, marm_su.buom_alt_uom_factor, 1)as decimal(24,18))  AS decimal(38,10)) AS shpmt_su_qty 
		, sh_buom.freight_type_code
		, ftc.fincl_cc_account_code
		, sh_buom.missing_alt_uom_g11_marm_flag
		, IF(marm_su.prod_id IS NOT NULL, 'N', 'Y')      AS missing_su_uom_g11_marm_flag
		, 'N' as generate_row_flag
	FROM (SELECT shs.cal_year_mth_num
				, shs.site_code
				, shs.prod_id
				, shs.base_uom
				, shs.freight_type_code
				, SUM(cast(shs.shpmt_alt_uom_qty * IF(marm.prod_id IS NOT NULL, marm.alt_uom_buom_factor   ,0) AS decimal(38,10))) AS shpmt_buom_qty  
				, MAX(IF(marm.prod_id    IS NOT NULL, 'N', 'Y'))       AS missing_alt_uom_g11_marm_flag
			FROM {target_db_name}.shpmt_alt_uom_sfct shs  
		LEFT JOIN {target_db_name}.prod_alt_uom_sdim marm  
				ON shs.prod_id = marm.prod_id  
			AND marm.alt_uom = shs.shpmt_alt_uom
		GROUP BY shs.prod_id, shs.site_code, shs.base_uom, shs.cal_year_mth_num, shs.freight_type_code
		) sh_buom
	LEFT JOIN {target_db_name}.prod_alt_uom_sdim marm_su 
		ON sh_buom.prod_id = marm_su.prod_id  
		AND marm_su.alt_uom = 'SU'
	LEFT JOIN {target_db_name}.fincl_cc_lkp ftc 
		ON sh_buom.freight_type_code = ftc.freight_type_code  
     """

    shpmt_sfct1 = spark.sql(query1)
    shpmt_sfct1.createOrReplaceTempView("shpmt_sfct_vw")

    query2 = f"""
    SELECT sh2.cal_year_mth_num
        , pse2.site_code
        , sh2.prod_id
        , sh2.base_uom, 0 as shpmt_buom_qty
        , sh2.buom_su_factor
        , 0 as shpmt_su_qty
        , sh2. freight_type_code
        , sh2.fincl_cc_account_code
        , 'N' AS missing_alt_uom_g11_marm_flag
        , 'N' AS missing_su_uom_g11_marm_flag
        , 'Y' as generate_row_flag
    FROM (select
                sh.prod_id, sh.base_uom, sh.buom_su_factor
                , sh.freight_type_code, sh.fincl_cc_account_code
                , sites.reference_site_code, sh.cal_year_mth_num  
            from shpmt_sfct_vw sh
            JOIN {target_db_name}.site_metadata_lkp sites  
                ON sh.site_code = sites.site_code
            AND UPPER(sites.calc_type_code) = 'AVERAGE'
            GROUP BY sh.prod_id, sh.base_uom, sh.buom_su_factor, sh.freight_type_code, sh.fincl_cc_account_code
                , sites.reference_site_code, sh.cal_year_mth_num
        ) sh2
    JOIN {target_db_name}.site_metadata_lkp pse2  
        ON sh2.reference_site_code = pse2.reference_site_code
    AND UPPER(pse2.calc_type_code) = 'AVERAGE'
    LEFT JOIN shpmt_sfct_vw sh_out
        ON pse2.site_code = sh_out.site_code
    AND sh2.prod_id =  sh_out.prod_id
    AND sh2.freight_type_code = sh_out.freight_type_code
    WHERE sh_out.site_code IS NULL AND sh_out.prod_id IS NULL and sh_out.freight_type_code IS NULL
    """
    shpmt_sfct2 = spark.sql(query2)

    shpmt_sfct = shpmt_sfct1.union(shpmt_sfct2)

    # Align the final dataframe with correct schema

    shpmt_sfct_final = shpmt_sfct.select(
        [shpmt_sfct[col.name].cast(col.dataType).alias(col.name) for col in tgt_schema]
    )

    shpmt_sfct_final.write.format("delta").mode("overwrite").saveAsTable(
        f"{target_db_name}.{target_table}"
    )

    logger.info(
        "Data has been successfully loaded into {}.{}".format(
            target_db_name, target_table
        )
    )

    return 0


def main():

    spark = get_spark()
    dbutils = get_dbutils()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    catalog, schema = config["catalog-name"], config["schema-name"]

    schema = f"{config['catalog-name']}.{config['schema-name']}"

    target_table = f"{config['tables']['shpmt_sfct']}"

    insertShpmtSfct(
        spark=spark, logger=logger, target_db_name=schema, target_table=target_table
    )


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
