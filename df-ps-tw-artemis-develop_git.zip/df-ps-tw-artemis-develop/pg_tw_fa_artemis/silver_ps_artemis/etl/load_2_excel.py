import logging
import os
import re
import sys
from datetime import datetime

import numpy as np
import openpyxl
import pandas as pd
import pyspark.sql.functions as f
from pandas import read_excel
from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql.types import StringType, StructField, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def get_file_list_in_dir(fs_excel_dir_path):
    "List files in a directory & subdirectories (RECURSIVE function)"

    file_dir_list = []
    new_obj_path = fs_excel_dir_path
    for filename in os.listdir(fs_excel_dir_path):
        new_obj_path = os.path.join(fs_excel_dir_path, filename)

        if os.path.isfile(new_obj_path):
            file_dir_list.append((os.path.dirname(new_obj_path), new_obj_path))
        elif os.path.isdir(new_obj_path):
            file_dir_list += get_file_list_in_dir(new_obj_path)

    return file_dir_list


def archive_directory(logger, dir_to_archive, archive_dir, archive_format):
    """Archive (compress & move to archive directory) a directory."""
    logger.info("Archiving the directory: {}".format(dir_to_archive))
    import time

    archive_file_name = (
        time.strftime("%Y%m%d_%H%M%S") + "__" + dir_to_archive.strip("/").split("/")[-1]
    )
    logger.info("Archive file name: {}".format(archive_file_name))
    import shutil

    archived_file_path = shutil.make_archive(
        base_name=archive_file_name, format=archive_format, root_dir=dir_to_archive
    )
    moved_archived_file_path = shutil.move(archived_file_path, archive_dir)
    logger.info(
        "Directory {} has been archived to {}".format(
            dir_to_archive, moved_archived_file_path
        )
    )
    return 0


def load_excels_2_staging_table(
    logger,
    spark,
    file_dir_list,
    target_table,
    target_table_name,
    partition_columns,
    sheetname,
    excel_skiprows,
    excel_header,
    excel_dropcols,
    fs_excel_dir_path,
):
    """Function converting excel to spark DF and inserting it to a table"""

    logger.info("Starting converting the excel file")

    part_cols_list = partition_columns.replace(" ", "").split(",")

    while "" in part_cols_list:
        part_cols_list.remove("")

    target_table_cols = [
        col
        for col in spark.table(target_table).columns
        if col != "last_update_utc_tmstp"
    ]

    excel_cols = [
        col
        for col in spark.table(target_table).drop(*part_cols_list).columns
        if col != "last_update_utc_tmstp"
    ]

    excel_cols_nmb = len(excel_cols)

    excel_converters = {i: str for i in range(0, int(excel_cols_nmb))}
    target_schema = StructType(
        [StructField(col, StringType(), True) for col in target_table_cols]
    )
    excel_spark_df = spark.createDataFrame([], target_schema)
    pandas_schema = StructType(
        [StructField(col, StringType(), True) for col in excel_cols]
    )
    for excel_path in file_dir_list:
        logger.info("Converting the following excel: {}".format(excel_path[1]))
        partition_from_dirs = excel_path[0].replace(fs_excel_dir_path, "").split("/")
        excel_pandas_df = pd.read_excel(
            io=excel_path[1],
            sheet_name=sheetname,
            converters=excel_converters,
            skiprows=excel_skiprows,
            header=excel_header,
        )
        excel_pandas_df = excel_pandas_df[
            excel_pandas_df.columns[0 : int(excel_cols_nmb)]
        ].replace({np.nan: None})
        if excel_dropcols:
            columns_to_be_dropped = [col.strip() for col in excel_dropcols.split(",")]
            excel_pandas_df = excel_pandas_df.drop(columns_to_be_dropped, axis=1)
        excel_tmp_spark_df = spark.createDataFrame(excel_pandas_df, pandas_schema)
        for index, partition_col in enumerate(part_cols_list):
            excel_tmp_spark_df = excel_tmp_spark_df.withColumn(
                partition_col, f.lit(partition_from_dirs[index])
            )

        excel_spark_df = excel_spark_df.union(excel_tmp_spark_df)
    excel_spark_df.createOrReplaceTempView(f"{target_table_name}")

    if "site_metadata_lkp" == f"{target_table_name}":
        site_md_query = f"""
            SELECT site_code
                , site_name
                , gedb_status_code
                , site_type_desc
                , company_code
                , country_name
                , region_name
                , sc_code
                , sap_box_name
                , cycle_name
                , alloc_name
                , calc_type_code
                , reference_site_code
                , control_plant_sender_code
                , subsector_name
                , cast(cast(regexp_replace(subsector_split_pct, '%', '') as decimal(10,4))/100 as decimal(10,4)) as subsector_split_pct
                , CASE 
                    WHEN UPPER(special_transfer_ce_flag) = 'YES' 
                    THEN 'Y'
                    WHEN UPPER(special_transfer_ce_flag) = 'NO' 
                    THEN 'N'
                    ELSE special_transfer_ce_flag
                    END AS special_transfer_ce_flag
                , plant_pallet_type1_code
                , plant_pallet_type2_code
                , plant_pallet_type3_code
                , cast(cast(regexp_replace(space_pct, '%', '') as decimal(10,4))/100 as decimal(10,4)) as space_pct
                , cast(cast(regexp_replace(infra_pct, '%', '') as decimal(10,4))/100 as decimal(10,4)) as infra_pct
                , cast(cast(regexp_replace(handling_pct, '%', '') as decimal(10,4))/100 as decimal(10,4)) as handling_pct
                , CASE 
                    WHEN UPPER(cycle_flag) = 'YES' 
                    THEN 'Y'
                    WHEN UPPER(cycle_flag) = 'NO' 
                    THEN 'N'
                    ELSE cycle_flag
                    END AS cycle_flag
                , snd_name
                , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as last_update_utc_tmstp
            FROM {target_table_name}
            WHERE site_code <> '' and site_code IS NOT NULL
        """
        final_lkp_table = spark.sql(site_md_query)

        final_lkp_table.write.format("delta").mode("overwrite").saveAsTable(
            f"{target_table}"
        )

    elif "fincl_cc_lkp" == f"{target_table_name}":

        query = f"""
                SELECT freight_type_code
                    , fincl_cc_account_code
                    , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as last_update_utc_tmstp
                    FROM {target_table_name}"""
        final_lkp_table = spark.sql(query)
        final_lkp_table.write.format("delta").mode("overwrite").saveAsTable(
            f"{target_table}"
        )

    elif "freight_type_lkp" == f"{target_table_name}":
        query = f""" 
            SELECT order_type_code
                , site_code
                , sold_to_customer_id
                , sold_to_affiliate_flag
                , vltn_class_code
                , nro_flag
                , freight_type_code
                , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as last_update_utc_tmstp
                , sap_source_system_id
            FROM {target_table_name}   
        """
        final_lkp_table = spark.sql(query)
        part_col = partition_columns.replace(" ", "").split(",")[0]
        final_lkp_table.write.format("delta").mode("overwrite").partitionBy(
            part_col
        ).saveAsTable(f"{target_table}")

    logger.info("The excel data has been loaded into {} table".format(target_table))

    return 0


def main():

    spark = get_spark()
    dbutils = get_dbutils()
    config = Configuration.load_for_default_environment(__file__, dbutils)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    try:
        args = sys.argv
        excel_dir_name = args[1]
        table_name = args[2]

        target_schema = f"{config['catalog-name']}.{config['schema-name']}"
        fs_excel_dir_path = f"{config['volume-dir']}/input/{excel_dir_name}/"
        archive_dir_path = f"{config['volume-dir']}/archive/"
        sheetname = f"{config['sheet_name'][table_name]}"
        target_table_name = f"{config['tables'][table_name]}"
        target_table = f"{target_schema}.{target_table_name}"

        excel_skiprows = 0
        excel_header = 0
        excel_dropcols = ""

        if "freight_type_lkp" in target_table_name:
            partition_columns = "sap_source_system_id"
        else:
            partition_columns = ""

        file_dir_list = get_file_list_in_dir(fs_excel_dir_path)

        load_excels_2_staging_table(
            logger,
            spark,
            file_dir_list,
            target_table,
            target_table_name,
            partition_columns,
            sheetname,
            excel_skiprows,
            excel_header,
            excel_dropcols,
            fs_excel_dir_path,
        )

        # Archive excels if archive dir is not empty
        if archive_dir_path:
            # We do use shell/python commnad, not dbuitls, so the path has to be changed
            archive_directory(logger, fs_excel_dir_path, archive_dir_path, "bztar")

        logger.info("execution ended")

    except Exception as exception:
        error_desc = "exception: {} at {}".format(type(exception), datetime.now())
        print(error_desc)
        sys.stderr.write(error_desc)
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logger.error(exception)
        sys.stdout.flush()
        sys.exit(1)


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
