import logging
import sys
from datetime import datetime

from dateutil.relativedelta import relativedelta
from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import DataType, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def insertShpmtVolReconciliationSstarCopy(
    spark, logger, run_year_mnt, target_db_name, target_table
):

    query = f"""
    SELECT rep.cal_year_mth_num, rep.site_code, rep.site_name
        , rep.site_type_code, rep.site_type_desc, rep.company_code
        , rep.site_region_name, rep.site_region_short_name, rep.site_sub_region_name, rep.site_sub_region_short_name
        , rep.site_geoc_area_name, rep.site_geoc_area_short_name, rep.site_country_name, rep.site_country_code         
        , refs.prod_id, refs.prod_name, refs.prod_subsector_name, refs.prod_subsector_id
        , refs.prod_categ_name, refs.prod_categ_id, refs.prod_tdcval_code, refs.prod_tdcval_desc
        , refs.freight_type_code, refs.fincl_cc_account_code
        , refs.base_uom, refs.shpmt_buom_qty  
        , refs.buom_su_factor, refs.shpmt_su_qty
        , UPPER(rep.calc_type_code) as calc_type_code
    FROM (SELECT rep1.site_code                      
                , rep1.site_name                      
                , rep1.site_type_code                 
                , rep1.site_type_desc                 
                , rep1.company_code                   
                , rep1.site_region_name               
                , rep1.site_region_short_name         
                , rep1.site_sub_region_name           
                , rep1.site_sub_region_short_name     
                , rep1.site_geoc_area_name            
                , rep1.site_geoc_area_short_name      
                , rep1.site_country_name              
                , rep1.site_country_code              
                , pse.reference_site_code
                , rep1.cal_year_mth_num
                , UPPER(pse.calc_type_code) as calc_type_code
            FROM {target_db_name}.shpmt_report_star rep1
            JOIN {target_db_name}.site_metadata_lkp pse 
            ON rep1.site_code = pse.site_code
            AND UPPER(pse.calc_type_code) = 'COPY'
        WHERE rep1.cal_year_mth_num = {run_year_mnt}
        GROUP BY rep1.site_code, rep1.site_name, rep1.site_type_code, rep1.site_type_desc, rep1.company_code, rep1.site_region_name               
                , rep1.site_region_short_name, rep1.site_sub_region_name, rep1.site_sub_region_short_name, rep1.site_geoc_area_name            
                , rep1.site_geoc_area_short_name, rep1.site_country_name, rep1.site_country_code, pse.reference_site_code
                , rep1.cal_year_mth_num, UPPER(pse.calc_type_code)
        ) rep
    LEFT JOIN (SELECT rep1.prod_id, pseo.reference_site_code, rep1.prod_name, rep1.prod_subsector_name, rep1.prod_subsector_id
                    , rep1.prod_categ_name, rep1.prod_categ_id, rep1.prod_tdcval_code, rep1.prod_tdcval_desc
                    , rep1.freight_type_code, rep1.fincl_cc_account_code
                    , rep1.base_uom, rep1.shpmt_buom_qty  
                    , rep1.buom_su_factor, rep1.shpmt_su_qty 
            FROM {target_db_name}.shpmt_vol_reconciliation_sstar rep1  
            JOIN (SELECT DISTINCT reference_site_code 
                    FROM {target_db_name}.site_metadata_lkp pse
                    WHERE UPPER(pse.calc_type_code) = 'COPY'
                )pseo
                ON rep1.site_code = pseo.reference_site_code
            WHERE rep1.cal_year_mth_num = {run_year_mnt}
        ) refs
        ON refs.reference_site_code = rep.reference_site_code
    """

    shpmt_vol_reconciliation_sstar = spark.sql(query)
    # df.display()

    shpmt_vol_reconciliation_sstar.write.format("delta").mode("overwrite").option(
        "replaceWhere", "calc_type_code = 'COPY'"
    ).partitionBy("calc_type_code").saveAsTable(f"{target_db_name}.{target_table}")

    logger.info(
        "Data has been successfully loaded into {}.{}".format(
            target_db_name, target_table
        )
    )

    return 0


def main():

    spark = get_spark()
    dbutils = get_dbutils()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    catalog, schema = config["catalog-name"], config["schema-name"]

    schema = f"{config['catalog-name']}.{config['schema-name']}"

    args = sys.argv

    run_year_mnt = int(args[1])

    target_table = f"{config['tables']['shpmt_vol_reconciliation_sstar']}"

    insertShpmtVolReconciliationSstarCopy(
        spark=spark,
        logger=logger,
        run_year_mnt=run_year_mnt,
        target_db_name=schema,
        target_table=target_table,
    )


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
