import logging
import os
import sys
from datetime import datetime

from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import *
from spclient import SPClient

from pg_tw_fa_artemis.common import get_dbutils, get_spark
from pg_tw_fa_artemis.spclient import *


def main():
    """Main"""
    spark = get_spark()

    dbutils = get_dbutils()

    config = Configuration.load_for_default_environment(__file__, dbutils)

    target_dir = f"{config['volume-dir']}/input"
    sharepoint_server = config["sharepoint-server"]
    sharepoint_site_path = config["sharepoint-site-path"]
    sharepoint_dir_path = config["sharepoint-dir-path"]
    sharepoint_max_lvl = config["sharepoint-max-lvl"]
    sharepoint_user = config["sharepoint-user"]
    user_pass = config["artemis-pass"]

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    try:

        sp_client = SPClient(
            username=sharepoint_user,
            password=user_pass,
            edge_point=sharepoint_server,
            site=sharepoint_site_path,
        )

        sp_client.load_directory(
            rel_path=sharepoint_dir_path,
            target_dir=target_dir,
            clear_target_dir=True,
            max_lvl=int(sharepoint_max_lvl),
        )
        logger.info(
            "execution ended, Sharepoint files downloded into volume...%s", target_dir
        )

    except Exception as exception:
        error_desc = "exception: {} at {}".format(type(exception), datetime.now())
        print(error_desc)
        sys.stderr.write(error_desc)
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logger.error(exception)
        sys.stdout.flush()
        sys.exit(1)


if __name__ == "__main__":
    main()
