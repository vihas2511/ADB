import builtins

# importing required packages
import csv
import datetime
import itertools
import logging
import os
import re
from collections import defaultdict, namedtuple
from datetime import date, datetime, timedelta
from functools import reduce
from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd
import pydomo
import pydomo.streams
import pyspark.sql.functions as f
import pyspark.sql.types as t
from dateutil.relativedelta import relativedelta
from pg_composite_pipelines_configuration.configuration import Configuration
from pydomo.datasets import *
from pydomo.streams import *
from pyspark.sql import DataFrame, SparkSession, types
from pyspark.sql.functions import *
from pyspark.sql.functions import col, to_timestamp
from pyspark.sql.types import *
from pyspark.sql.types import DataType, FloatType, StructType
from pyspark.sql.window import Window

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def initialize_domo_client(config):
    """
    Initialize and return a Domo client instance.

    Parameters:
        config (dict): Configuration dictionary containing Domo credentials with keys:
                       - 'domoclientid': The Domo client ID.
                       - 'domosecret': The Domo secret.
                       - 'api_host': The Domo API host (default is 'api.domo.com').

    Returns:
        domo (pydomo.Domo): An authenticated Domo client instance.
    """
    DomoClientID = config["domoclientid"]
    DomoSecret = config["domosecret"]
    api_host = "api.domo.com"
    # Default to 'api.domo.com' if not provided

    domo = pydomo.Domo(
        client_id=DomoClientID, client_secret=DomoSecret, api_host=api_host
    )
    return domo


def csv_partitions(dbutils, csv_folder, forDomoUpload=False):
    # get components of a partitioned csv data into a list
    # for domo uploads the path has to be altered
    if forDomoUpload == True:
        output = (
            path[0].replace("dbfs:", "")
            for path in dbutils.fs.ls(csv_folder)
            if path[1].startswith("part")
        )
    else:
        output = (
            path[0] for path in dbutils.fs.ls(csv_folder) if path[1].startswith("part")
        )
    return list(output)


def generate_domo_schema(dataframe):
    # generate a python code which defines the schema of the dataset for DOMO API
    datatype_list = dataframe.dtypes
    domo_schema = []
    keys = ["type", "name"]
    k = 0
    for i in datatype_list:
        dicts = {}
        dicts[k] = {}
        # if i[1]=='string':
        if i[1] in ['"', "string", "timestamp", "binary"]:
            data_type = "STRING"
        elif i[1] in ["int", "bigint", "long"]:
            data_type = "LONG"
        elif "decimal" in i[1]:
            data_type = "DECIMAL"
        elif i[1] == "date":
            data_type = "DATE"
        else:
            data_type = "DOUBLE"
        dicts[k][keys[0]] = data_type
        dicts[k][keys[1]] = i[0]
        domo_schema.append(dicts[k])
        k += 1
    return domo_schema


# DOMO DATASETS
def create_domo_dataset(domo, dataframe_source, domo_dataset_name, domo_dataset_descr):
    # create domo dataset
    dsr = DataSetRequest()
    dsr.name = domo_dataset_name
    dsr.description = domo_dataset_descr

    dsr.schema = Schema(generate_domo_schema(dataframe_source))
    dataset = domo.datasets.create(dsr)
    print("New DataSet Created: {} (id: {})".format(dataset["name"], dataset["id"]))


def update_domo_dataset_schema(
    dbutils, domo, domo_dataset_id, dataframe_source, domo_dataset_descr
):
    # update domo dataset schema
    dsr = DataSetRequest()
    dsr.description = domo_dataset_descr
    # dsr.schema = Schema(eval(generate_domo_schema(dataframe_source)))
    dsr.schema = Schema(generate_domo_schema(dataframe_source))
    updated_dataset = domo.datasets.update(domo_dataset_id, dsr)
    print("Updated DataSet {}:".format(updated_dataset["id"]))


def upload_csv_to_domo_dataset(dbutils, domo, domo_dataset_id, csv_folder, method):
    # function pushes data to domo dataset
    # it replaces all the data in the dataset
    print("Using Domo Datasets...")
    parts = list(csv_partitions(dbutils, csv_folder, forDomoUpload=True))
    error = False

    if method == "append":
        load_type = UpdateMethod.APPEND
    else:
        print("replace")
        load_type = UpdateMethod.REPLACE

    for part_no, part in enumerate(parts):
        print("{}/{} - {}".format(part_no + 1, len(parts), part))
        if part_no == 0:
            try:
                domo.datasets.data_import_from_file(
                    domo_dataset_id, filepath=part, update_method=load_type
                )
            except Exception as e:
                error = True
                print(e)
        else:
            try:
                domo.datasets.data_import_from_file(
                    domo_dataset_id, filepath=part, update_method=load_type
                )
            except Exception as e:
                error = True
                print(e)

    if error:
        print("upload aborted due to error")


def upload_csv_to_domo_stream(dbutils, domo, domo_dataset_id, csv_folder, method):
    # upload csv through domo streams
    print("Using Streams...")
    print(method)
    streams = domo.streams.search("dataSource.id:{}".format(domo_dataset_id))
    if not streams:
        raise "Stream not found for datasource " + domo_dataset_id

    domo_stream_id = streams[0]["id"]
    parts = list(csv_partitions(dbutils, csv_folder, forDomoUpload=True))

    if method == "append":
        execution = domo.streams.create_execution(
            domo_stream_id, pydomo.streams.UpdateMethod.APPEND
        )
    else:
        print("replace")
        execution = domo.streams.create_execution(
            domo_stream_id, pydomo.streams.UpdateMethod.REPLACE
        )

    execution_id = execution["id"]
    print(execution_id)
    error = False
    for part_no, part in enumerate(parts):
        print("{}/{} - {}".format(part_no + 1, len(parts), part))
        try:
            domo.streams.upload_csv_part_from_file(
                domo_stream_id,
                execution_id,
                part_num=part_no,
                filepath=part,
                compression=None,
            )
        except Exception as e:
            error = True
            print(e)
    if error:
        domo.streams.abort_current_execution(domo_stream_id)
        print("upload aborted due to error")
    else:
        domo.streams.commit_execution(domo_stream_id, execution_id)


def domo_dataset_uploader_tool(
    dbutils,
    domo,
    domo_dataset_id,
    csv_folder,
    dataframe_source,
    method,
    domo_dataset_name=None,
    domo_dataset_descr=None,
    updateSchema=True,
    batchSize=None,
    useStreams=True,
):
    # uploader tool to combine the steps necessary for a domo push into one function

    # initiate domo connection

    print("DOMO UPLOAD SEQUENCE START...")
    if dataframe_source is None:
        return print("Error: 'dataframe_source' not specified!")
    else:
        # save partitioned data into csv
        print("Writing data into csv...")
        dataframe_source.write.mode("overwrite").option("emptyValue", "").csv(
            csv_folder, header=False
        )

    # update dataframe schema
    if updateSchema == True:
        print("update schema")
        update_domo_dataset_schema(
            dbutils, domo, domo_dataset_id, dataframe_source, domo_dataset_descr
        )

    # upload data into domo
    if useStreams:
        print("stream loop")
        upload_csv_to_domo_stream(dbutils, domo, domo_dataset_id, csv_folder, method)
    else:
        print("dataset loop")
        upload_csv_to_domo_dataset(dbutils, domo, domo_dataset_id, csv_folder, method)
    print("DOMO UPLOAD SEQUENCE COMPLETED!")


def process_and_upload_data(
    dbutils,
    domo,
    logger,
    spark,
    db_name,
    cal_year_mth,
    table_name,
    OUTPUT_FOLDER,
    dataset_id,
):
    logger.info("reading table_name %s", table_name)

    if table_name == "shpmt_report_star":
        simp_data = spark.sql(
            f"""
            SELECT shp.cal_year_mth_num as fiscal_period
     , shp.site_code, shp.site_name
     , shp.site_type_code, shp.site_type_desc as site_type
     , shp.company_code as legal_entity
     , shp.site_region_name as site_region
     , shp.site_region_short_name, shp.site_sub_region_name as site_sub_region, shp.site_sub_region_short_name
     , shp.site_geoc_area_name as site_geographic_group
     , shp.site_geoc_area_short_name as site_geographic_group_short_name
     , shp.site_country_name as site_country, shp.site_country_code         
     , substr(shp.prod_id, -8) as material_code, shp.prod_name as material_description
     , shp.prod_subsector_name as subsector
     , shp.prod_subsector_id as subsector_ID
     , shp.prod_categ_name as category
     , shp.prod_categ_id as category_ID
     , shp.prod_tdcval_code as TDCVal
     , shp.prod_tdcval_desc as TDCVal_description
     , shp.freight_type_code as ship_type
     , shp.fincl_cc_account_code as `account_#`
     , shp.base_uom as BUoM
     , shp.shpmt_buom_qty as BUoM_shipped
     , shp.buom_su_factor as SU_per_BUoM
     , shp.shpmt_su_qty as SU_Shipped
     , shp.missing_alt_uom_g11_marm_flag as `Alternative_UoM_to_BUoM_conversion_is_missing_in_G11_(Y/N)`
     , shp.missing_su_uom_g11_marm_flag as `SU_to_BUoM_conversion_is_missing_in_G11_(Y/N)`
     , shp.last_update_utc_tmstp
     , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as domo_extract_utc_tmstp
  FROM {db_name}.shpmt_report_star shp
 WHERE shp.cal_year_mth_num = cast('{cal_year_mth}' as int)
            """
        )
    else:
        simp_data = spark.sql(
            f"""SELECT shp.cal_year_mth_num as fiscal_period
     , shp.site_code, shp.site_name
     , shp.site_type_code, shp.site_type_desc as site_type_desc
     , shp.company_code as legal_entity
     , shp.site_region_name as site_region
     , shp.site_region_short_name, shp.site_sub_region_name as site_sub_region, shp.site_sub_region_short_name
     , shp.site_geoc_area_name as site_geographic_group
     , shp.site_geoc_area_short_name as site_geographic_group_short_name
     , shp.site_country_name as site_country, shp.site_country_code         
     , substr(shp.prod_id, -8) as material_code, shp.prod_name as material_description
     , shp.prod_subsector_name as subsector
     , shp.prod_subsector_id as subsector_ID
     , shp.prod_categ_name as category
     , shp.prod_categ_id as category_ID
     , shp.prod_tdcval_code as TDCVal
     , shp.prod_tdcval_desc as TDCVal_description
     , shp.freight_type_code as ship_type
     , shp.fincl_cc_account_code as `account_#`
     , shp.base_uom as BUoM
     , shp.shpmt_buom_qty as BUoM_shipped
     , shp.buom_su_factor as SU_per_BUoM
     , shp.shpmt_su_qty as SU_Shipped
     , shp.last_update_utc_tmstp
     , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as domo_extract_utc_tmstp
  FROM {db_name}.shpmt_vol_reconciliation_report_star shp
 WHERE shp.cal_year_mth_num =  cast('{cal_year_mth}' as int)"""
        )

    binary_columns = [
        col_name for (col_name, col_type) in simp_data.dtypes if col_type == "binary"
    ]
    # Convert binary columns to strings
    for col_name in binary_columns:
        simp_data = simp_data.withColumn(col_name, f.col(col_name).cast("string"))

    from pyspark.sql.functions import col, regexp_replace

    # Define the replacement condition
    replacement_pattern = r'[//"]+'
    replacement = ""

    # Loop through each column
    for col_name in simp_data.columns:
        # Apply the replacement condition to the column values
        expr = regexp_replace(col(col_name), replacement_pattern, replacement)
        # Apply the expression to the DataFrame column
        simp_data = simp_data.withColumn(col_name, expr)

        simp_data = (
            simp_data.withColumn(
                "domo_extract_utc_tmstp", to_timestamp("domo_extract_utc_tmstp")
            )
            .withColumn("last_update_utc_tmstp", to_timestamp("domo_extract_utc_tmstp"))
            .withColumn(
                "BUoM_shipped",
                simp_data["BUoM_shipped"].cast(FloatType()),
            )
            .withColumn(
                "SU_per_BUoM",
                simp_data["SU_per_BUoM"].cast(FloatType()),
            )
            .withColumn(
                "SU_Shipped",
                simp_data["SU_Shipped"].cast(FloatType()),
            )
            .withColumn(
                "fiscal_period",
                simp_data["fiscal_period"].cast(IntegerType()),
            )
        )

    count = simp_data.count()
    logger.info("count %s", count)

    # Define the path to the mounted directory
    mounted_path = OUTPUT_FOLDER

    # Delete files in the directory
    try:
        files = dbutils.fs.ls(mounted_path)
        for file in files:
            dbutils.fs.rm(file.path, recurse=True)
            # print(f"Deleted: {file.path}")
    except Exception as e:
        print("file not found skipping deletion")

    if count != 0:
        logger.info("exporting table_name %s", table_name)
        CSV_OUTPUT_FILE_DATA = OUTPUT_FOLDER
        domo_dataset_uploader_tool(
            dbutils,
            domo,
            domo_dataset_id=dataset_id,
            csv_folder=CSV_OUTPUT_FILE_DATA,
            dataframe_source=simp_data,
            domo_dataset_descr="",
            updateSchema=True,
            method="replace",
        )
    else:
        print("count is zero")


def publish(config):
    """Publish to CDL medatada."""
    # initial config
    spark = get_spark()
    dbutils = get_dbutils()

    args = sys.argv
    print(args)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    table_name = args[1]
    cal_year_mth = args[2]

    domo = initialize_domo_client(config)

    OUTPUT_FOLDER = config["volume-dir"] + "/" + table_name

    dataset_id = config["dataset-id"][table_name]
    db_name = config["catalog-name"] + "." + config["schema-name"]

    process_and_upload_data(
        dbutils,
        domo,
        logger,
        spark,
        db_name,
        cal_year_mth,
        table_name,
        OUTPUT_FOLDER,
        dataset_id,
    )


def main():
    dbutils = get_dbutils()
    config = Configuration.load_for_default_environment(__file__, dbutils=dbutils)
    publish(config)


if __name__ == "__main__":
    main()
