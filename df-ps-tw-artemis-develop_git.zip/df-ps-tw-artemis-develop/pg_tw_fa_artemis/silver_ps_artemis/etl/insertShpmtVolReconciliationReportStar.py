import logging

from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import DataType, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def insertShpmtVolReconciliationReportStar(spark, logger, target_db_name, target_table):

    query = f"""
	SELECT rep2.site_code, rep2.site_name
     , rep2.site_type_code, rep2.site_type_desc, rep2.company_code
     , rep2.site_region_name, rep2.site_region_short_name, rep2.site_sub_region_name, rep2.site_sub_region_short_name
     , rep2.site_geoc_area_name, rep2.site_geoc_area_short_name, rep2.site_country_name, rep2.site_country_code         
     , rep2.prod_id, rep2.prod_name, rep2.prod_subsector_name, rep2.prod_subsector_id
     , rep2.prod_categ_name, rep2.prod_categ_id, rep2.prod_tdcval_code, rep2.prod_tdcval_desc
     , rep2.freight_type_code, rep2.fincl_cc_account_code
     , rep2.base_uom, rep2.shpmt_buom_qty  
     , rep2.buom_su_factor, rep2.shpmt_su_qty
     , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as last_update_utc_tmstp
     , rep2.cal_year_mth_num
  	FROM {target_db_name}.shpmt_vol_reconciliation_sstar rep2
     """

    shpmt_vol_reconciliation_report_star = spark.sql(query)

    shpmt_vol_reconciliation_report_star.write.format("delta").mode("overwrite").option(
        "partitionOverwriteMode", "dynamic"
    ).partitionBy("cal_year_mth_num").saveAsTable(f"{target_db_name}.{target_table}")

    logger.info(
        "Data has been successfully loaded into {}.{}".format(
            target_db_name, target_table
        )
    )

    return 0


def main():

    spark = get_spark()
    dbutils = get_dbutils()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    catalog, schema = config["catalog-name"], config["schema-name"]

    schema = f"{config['catalog-name']}.{config['schema-name']}"

    target_table = f"{config['tables']['shpmt_vol_reconciliation_report_star']}"

    insertShpmtVolReconciliationReportStar(
        spark=spark, logger=logger, target_db_name=schema, target_table=target_table
    )


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
