import logging
import sys

from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import DataType, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def insertShpmtReportStar(spark, logger, g11_db_name, target_db_name, target_table):

    query = f"""
    SELECT shp_refined.site_code, shp_refined.site_name
        , shp_refined.site_type_code, shp_refined.site_type_desc
        , shp_refined.company_code
        , shp_refined.site_region_name, shp_refined.site_region_short_name, shp_refined.site_sub_region_name, shp_refined.site_sub_region_short_name
        , shp_refined.site_geoc_area_name, shp_refined.site_geoc_area_short_name, shp_refined.site_country_name, shp_refined.site_country_code
        , shp_refined.prod_id, shp_refined.prod_name
        , shp_refined.prod_subsector_name
        , shp_refined.prod_subsector_id
        , shp_refined.prod_categ_name
        , shp_refined.prod_categ_id
        , shp_refined.prod_tdcval_code
        , shp_refined.prod_tdcval_desc
        , shp_refined.freight_type_code
        , shp_refined.fincl_cc_account_code
        , shp_refined.base_uom
        , shp_refined.shpmt_buom_qty
        , shp_refined.buom_su_factor
        , shp_refined.shpmt_su_qty
        , shp_refined.missing_alt_uom_g11_marm_flag, shp_refined.missing_su_uom_g11_marm_flag
        , shp_refined.last_update_utc_tmstp
        , shp_refined.cal_year_mth_num
    
    FROM (SELECT shp.site_code, shp.site_name
            , shp.site_type_code, st_d.site_type_desc as site_type_desc
            , tlk.company_code as company_code
            , shp.site_region_name, shp.site_region_short_name, shp.site_sub_region_name, shp.site_sub_region_short_name
            , shp.site_geoc_area_name, shp.site_geoc_area_short_name, shp.site_country_name, shp.site_country_code
            , shp.prod_id, pd.name as prod_name
            , CASE WHEN (UPPER(phd.prod_5_name) LIKE '%PGP%') THEN 'PGP' ELSE phd.prod_3_name END as prod_subsector_name
            , CASE WHEN (UPPER(phd.prod_5_name) LIKE '%PGP%') THEN NULL ELSE phd.prod_3_id END AS prod_subsector_id
            , CASE WHEN (UPPER(phd.prod_5_name) LIKE '%PGP%') THEN CONCAT('PGP ',phd.prod_4_name) ELSE phd.prod_4_name END as prod_categ_name
            , CASE WHEN (UPPER(phd.prod_5_name) LIKE '%PGP%') THEN NULL ELSE phd.prod_4_id END AS prod_categ_id
            , SUBSTR(Z103.attr_value_abbr_code, 1, 5) as prod_tdcval_code
            , phd.prod_5_name  as prod_tdcval_desc
            , shp.freight_type_code as freight_type_code
            , shp.fincl_cc_account_code as fincl_cc_account_code
            , shp.base_uom
            , shp.shpmt_buom_qty
            , shp.buom_su_factor
            , shp.shpmt_su_qty
            , shp.missing_alt_uom_g11_marm_flag, shp.missing_su_uom_g11_marm_flag
            , to_utc_timestamp(from_unixtime(unix_timestamp()), 'PRT') as last_update_utc_tmstp
            , shp.cal_year_mth_num
            
            , row_number() OVER (PARTITION BY shp.site_code, shp.prod_id, shp.freight_type_code, shp.cal_year_mth_num ORDER BY shp.site_code) AS rownum
            
        FROM (SELECT shpmt.cal_year_mth_num
                    , shpmt.site_code
                    , t1w.part1_name as site_name
                    , t1w.site_type_code as site_type_code
                    , ghd.geo_2_long_name as site_region_name, ghd.geo_2_name as site_region_short_name
                    , ghd.geo_3_long_name as site_sub_region_name, ghd.geo_3_name as site_sub_region_short_name
                    , ghd.geo_4_long_name as site_geoc_area_name, ghd.geo_4_name as site_geoc_area_short_name
                    , ghd.geo_6_name as site_country_name, t1w.country_code as site_country_code
                    , shpmt.prod_id
                    , shpmt.base_uom
                    , shpmt.shpmt_buom_qty
                    , shpmt.buom_su_factor
                    , shpmt.shpmt_su_qty
                    , shpmt.freight_type_code
                    , shpmt.fincl_cc_account_code
                    , shpmt.missing_alt_uom_g11_marm_flag, shpmt.missing_su_uom_g11_marm_flag
                FROM {target_db_name}.shpmt_sfct shpmt
                LEFT JOIN 
                    (SELECT tw.werks as plant_id,tw.name1 as part1_name,tw.ZZSITETYPC as site_type_code,tw.LAND1 as country_code
                    FROM {g11_db_name}.t001w tw 
                    where tw.simp_chng_type_code not in ('I','U','D')  				 
                    union																
                    select plant_id,part1_name,site_type_code,country_code
                    from(SELECT tw.werks as plant_id,tw.name1 as part1_name,tw.ZZSITETYPC as site_type_code,tw.LAND1 as country_code, ROW_NUMBER() over(partition by werks,mandt order by bd_mod_utc_time_stamp desc )as rnk
                    FROM {g11_db_name}.t001w tw
                    where  simp_chng_type_code in ('I','U') )							
                    where rnk=1 				  										 
                    )t1w
                    ON shpmt.site_code  = t1w.plant_id
                    
                LEFT JOIN rds.geo_hier_dim ghd  
                    ON ghd.geo_hier_id = '705'
                    AND ghd.curr_ind = 'Y'
                    AND t1w.country_code= ghd.geo_6_iso_cntry_code
                ) shp
        LEFT JOIN 
                ( 
                SELECT Z4.MATNR as prod_id,Z4.ZATTRTYPID as attr_type_id,Z4.simp_chng_type_code,Z4.ZATTRVALID as attr_value_id
                FROM {g11_db_name}.ZTXXPT0104 Z4 
                WHERE Z4.simp_chng_type_code not in ('I','U','D')   					 
                union																	  
                select prod_id,attr_type_id,simp_chng_type_code,attr_value_id
                from(SELECT MATNR as prod_id,ZATTRTYPID as attr_type_id,simp_chng_type_code,ZATTRVALID as attr_value_id, ROW_NUMBER() over(partition by MATNR,ZATTRTYPID order by bd_mod_utc_time_stamp desc )as rnk
                FROM {g11_db_name}.ZTXXPT0104
                where  simp_chng_type_code in ('I','U') )								 
                where rnk=1															   
                ) Z104
                ON shp.prod_id = Z104.prod_id
                AND Z104.attr_type_id = 'TDC_VAL'
                
        LEFT JOIN 
                ( 
                SELECT Z3.ZATTRVALID as attr_value_id,Z3.ZATTRTYPID as attr_type_id,Z3.simp_chng_type_code,z3.ZATTRVALAB as attr_value_abbr_code
                FROM {g11_db_name}.ZTXXPT0103 Z3 
                where Z3.simp_chng_type_code not in ('I','U','D')   					   
                union																	  	
                select attr_value_id,attr_type_id,simp_chng_type_code,attr_value_abbr_code
                from(SELECT Z3.ZATTRVALID as attr_value_id,Z3.ZATTRTYPID as attr_type_id,Z3.simp_chng_type_code,Z3.ZATTRVALAB as attr_value_abbr_code, ROW_NUMBER() over(partition by ZATTRVALID,ZATTRTYPID order by bd_mod_utc_time_stamp desc )as rnk
                FROM {g11_db_name}.ZTXXPT0103 Z3
                where simp_chng_type_code in ('I','U') )								
                where rnk=1															   
                ) Z103
                ON Z104.attr_value_id = Z103.attr_value_id
                AND Z104.attr_type_id = Z103.attr_type_id
                
        LEFT JOIN rds.prod_hier_dim phd
                ON phd.prod_hier_id = '680'
                AND phd.curr_ind = 'Y'
                AND CONCAT('0000', SUBSTR(Z103.attr_value_abbr_code, 1, 5)) = phd.prod_5_id
                AND phd.sfct_load_err_ind = 'N' 
                AND phd.sdim_load_err_ind = 'N'
        LEFT JOIN rds.prod_dim pd
                ON pd.curr_ind = 'Y'
                AND pd.sfct_load_err_ind = 'N' 
                AND pd.sdim_load_err_ind = 'N'
                AND REGEXP_REPLACE(shp.prod_id, '^0*','') = pd.prod_id
        LEFT JOIN 
                (SELECT tk.BUKRS as company_code,tk.BWKEY as site_code,tk.simp_chng_type_code
                FROM {g11_db_name}.T001K tk 
                where tk.simp_chng_type_code not in ('I','U','D')   					  
                union																			
                select company_code,site_code,simp_chng_type_code
                from(SELECT tk.BUKRS as company_code,tk.BWKEY as site_code,tk.simp_chng_type_code, ROW_NUMBER() over(partition by BUKRS,BWKEY order by bd_mod_utc_time_stamp desc )as rnk
                FROM {g11_db_name}.T001K tk
                where  simp_chng_type_code in ('I','U') )								
                where rnk=1															 				  
                )tlk 
                ON shp.site_code  = tlk.site_code
                
        LEFT JOIN {target_db_name}.pallet_alloc_site_type_dim st_d
            ON shp.site_type_code = st_d.site_type_code
        ) shp_refined
    
    WHERE shp_refined.rownum = 1 
    """

    shpmt_report_star = spark.sql(query)

    shpmt_report_star.write.format("delta").mode("overwrite").option(
        "partitionOverwriteMode", "dynamic"
    ).partitionBy("cal_year_mth_num").saveAsTable(f"{target_db_name}.{target_table}")

    logger.info(
        "Data has been successfully loaded into {}.{}".format(
            target_db_name, target_table
        )
    )

    return 0


def main():
    spark = get_spark()
    dbutils = get_dbutils()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    catalog, schema = config["catalog-name"], config["schema-name"]

    g11_db_name = f"{config['src-catalog-name']}.{config['g11_db_name']}"

    schema = f"{config['catalog-name']}.{config['schema-name']}"

    target_table = f"{config['tables']['shpmt_report_star']}"

    insertShpmtReportStar(
        spark=spark,
        logger=logger,
        g11_db_name=g11_db_name,
        target_db_name=schema,
        target_table=target_table,
    )


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
