import argparse
import logging
import sys
from datetime import datetime

from dateutil.relativedelta import relativedelta
from pg_composite_pipelines_configuration.configuration import Configuration
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, upper
from pyspark.sql.types import DataType, StructType

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def insertShpmtVolReconciliationSstarStandard(
    spark, logger, run_year_mnt, target_db_name, target_table
):

    query = f"""
    SELECT rep1.cal_year_mth_num, rep1.site_code, rep1.site_name
     , rep1.site_type_code, rep1.site_type_desc, rep1.company_code
	   , rep1.site_region_name, rep1.site_region_short_name, rep1.site_sub_region_name, rep1.site_sub_region_short_name
     , rep1.site_geoc_area_name, rep1.site_geoc_area_short_name, rep1.site_country_name, rep1.site_country_code         
     , rep1.prod_id, rep1.prod_name, rep1.prod_subsector_name, rep1.prod_subsector_id
     , rep1.prod_categ_name, rep1.prod_categ_id, rep1.prod_tdcval_code, rep1.prod_tdcval_desc
     , rep1.freight_type_code, rep1.fincl_cc_account_code
     , rep1.base_uom, rep1.shpmt_buom_qty  
     , rep1.buom_su_factor, rep1.shpmt_su_qty
	   , UPPER(pse.calc_type_code) as calc_type_code
    FROM {target_db_name}.shpmt_report_star rep1
    JOIN {target_db_name}.site_metadata_lkp pse
    ON rep1.site_code = pse.site_code
    AND UPPER(pse.calc_type_code) <> 'AVERAGE'
    AND UPPER(pse.calc_type_code) <> 'COPY'
    WHERE rep1.cal_year_mth_num = {run_year_mnt}
    """

    spark.sql(query)

    shpmt_vol_reconciliation_sstar = spark.sql(query)

    shpmt_vol_reconciliation_sstar.write.format("delta").mode("overwrite").option(
        "replaceWhere", "calc_type_code = 'STANDARD'"
    ).partitionBy("calc_type_code").saveAsTable(f"{target_db_name}.{target_table}")

    logger.info(
        "Data has been successfully loaded into {}.{}".format(
            target_db_name, target_table
        )
    )

    return 0


def main():

    spark = get_spark()
    dbutils = get_dbutils()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    config = Configuration.load_for_default_environment(__file__, dbutils)

    catalog, schema = config["catalog-name"], config["schema-name"]

    schema = f"{config['catalog-name']}.{config['schema-name']}"

    args = sys.argv

    run_year_mnt = int(args[1])

    target_table = f"{config['tables']['shpmt_vol_reconciliation_sstar']}"

    insertShpmtVolReconciliationSstarStandard(
        spark=spark,
        logger=logger,
        run_year_mnt=run_year_mnt,
        target_db_name=schema,
        target_table=target_table,
    )


if __name__ == "__main__":
    # if you need to read params from your task/workflow, use sys.argv[] to retrieve them and pass them to main here
    # eg sys.argv[0] for first positional param
    main()
