--assume that schema exists and "use <schema>" was run

--$location is replaced at execution time by the migration library with the storage path passed to the migration library
--$schema is replaced at execution time by the schema name passed in
--other $values can be passed in using kwargs.  
--Read more about Migration library features and and details at https://github.com/procter-gamble/de-cf-ps-migration coment

CREATE SCHEMA IF NOT EXISTS $schema;

DROP TABLE IF EXISTS $schema.freight_type_lkp;
CREATE TABLE IF NOT EXISTS $schema.freight_type_lkp (
    order_type_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-AUART] SAP Sales order type.
    This is the same filtering criterion as in HYDRA for the sales orders'
    , site_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-PLANT_DVL] Site (plant) delivery code'
    , sold_to_customer_id STRING
    COMMENT '[ZVXX_TMS1_COSTAL-KUNAG] SAP Sold to Party.
    Internal/External Customer number which identifies the party which buys the goods from the specific plants'
    , sold_to_affiliate_flag STRING
    COMMENT '[ZVXX_TMS1_COSTAL-SOLDTO_AFF] Sold to Affiliate checkbox. 
    This should be the identifier for Affiliate/Export scenario but if you take a look at the mapping file it is not always true'
    , vltn_class_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-BKLAS] SAP Sales order Valuation Class. 
    This field can determine "FreightTyp" (Freight Type) but it is not included in the current determination logic'
    , nro_flag STRING
    COMMENT '[ZVXX_TMS1_COSTAL-NRO_FLAG] Flag: Is it Non-Revenue Order?'
    , freight_type_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-FREIGHT_TYPE] SAP Sales order Freight Type. 
    This classifies the sales order as:
	  - C - Customer (sales to P&G external customer)
	  - I - Intersite (internal sales to one of the P&G sites)
	  - E - Export/Affiliate (sales to P&G contractor)'
    , last_update_utc_tmstp TIMESTAMP
    COMMENT 'BigData Calculated field: Time Stamp of table row modification operation in '
    , sap_source_system_id STRING
    COMMENT 'SAP Source System'
) USING DELTA
PARTITIONED BY (sap_source_system_id)
COMMENT 'Mapping sites/sales documents to freight type'
LOCATION '$location/FREIGHT_TYPE_LKP';

DROP TABLE IF EXISTS $schema.site_metadata_lkp;
CREATE TABLE IF NOT EXISTS $schema.site_metadata_lkp (
    site_code STRING
    COMMENT 'Site (plant) code'
    , site_name STRING
    COMMENT 'Site (plant) name'
    , gedb_status_code STRING
    COMMENT 'GEDB status code'
    , site_type_desc STRING
    COMMENT 'Site (plant) type'
    , company_code STRING
    COMMENT 'Company code (legal entity)'
    , country_name STRING
    COMMENT 'Country name'
    , region_name STRING
    COMMENT 'Region name'
    , sc_code STRING
    COMMENT 'SC code'
    , sap_box_name STRING
    COMMENT 'SAP box name'
    , cycle_name STRING
    COMMENT 'Cycle name'
    , alloc_name STRING
    COMMENT 'Allocation type'
    , calc_type_code STRING
    COMMENT 'Calculation type code'
    , reference_site_code STRING
    COMMENT 'Reference site code'
    , control_plant_sender_code STRING
    COMMENT 'CTL Plant Sender'
    , subsector_name STRING
    COMMENT 'Subsector (BU)'
    , subsector_split_pct DECIMAL(10, 4)
    COMMENT 'Subsector (BU) split percent expressed as a number in 0-1 range.'
    , special_transfer_ce_flag STRING
    COMMENT 'Flag: Is it special transfer CE?'
    , plant_pallet_type1_code STRING
    COMMENT 'Default pallet type for the site (first option). 
    It is a substitute for the pallet type  from SAP DEF_MOL table.'
    , plant_pallet_type2_code STRING
    COMMENT 'Default pallet type for the site (second option). 
    It is a default pallet type for a plant if option 1 is empty.'
    , plant_pallet_type3_code STRING
    COMMENT 'Default pallet type for the site (third option).
    It is a fallback pallet type, when option 1 & 2 are empty.'
    , space_pct DECIMAL(10, 4)
    COMMENT 'Space percent expressed as a number in 0-1 range.'
    , infra_pct DECIMAL(10, 4)
    COMMENT 'Infra percent expressed as a number in 0-1 range.'
    , handling_pct DECIMAL(10, 4)
    COMMENT 'Handling percent expressed as a number in 0-1 range.'
    , cycle_flag STRING
    COMMENT 'Flag: is there a cycle?'
    , snd_name STRING
    COMMENT 'SND name'
    , last_update_utc_tmstp TIMESTAMP
    COMMENT 'BigData Calculated field: Time Stamp of table row modification operation in'
) USING DELTA
COMMENT 'Site metadata loaded from manual file. Contains meta data about site, eg. calculation logic exception per sites.'
LOCATION '$location/SITE_METADATA_LKP';

DROP TABLE IF EXISTS $schema.fincl_cc_lkp;
CREATE TABLE IF NOT EXISTS $schema.fincl_cc_lkp (
    freight_type_code STRING
    COMMENT 'SAP Sales order Freight Type. This classifies the sales order as:
    - C - Customer (sales to P&G external customer)
    - I - Intersite (internal sales to one of the P&G sites)
    - E - Export/Affiliate (sales to P&G contractor)'
    , fincl_cc_account_code STRING
    COMMENT 'Financal cost center to which we apply the distribution cost center number'
    , last_update_utc_tmstp TIMESTAMP
    COMMENT 'BigData Calculated field: Time Stamp of table row modification operation in '
) USING DELTA
COMMENT 'Mappping freight type to financial cost center code'
LOCATION '$location/FINCL_CC_LKP';

CREATE TABLE IF NOT EXISTS $schema.prod_alt_uom_sdim (
    prod_id STRING
    COMMENT '[MARM-MATNR] Product ID'
    , alt_uom STRING
    COMMENT '[MARM-MEINH] Alternative unit of measure (alternative uom / AuN)'
    , alt_uom_buom_factor DECIMAL(24, 18)
    COMMENT '[MARM-UMREZ]/[MARM-UMREN] Alternative uom to buom conversion factor ( numerator/ denominator ).'
    , buom_alt_uom_factor DECIMAL(24, 18)
    COMMENT '[MARM-UMREN]/[MARM-UMREZ]  Buom to alternative uom conversion factor (denominator / numerator).'
    , numerator_alt_uom_buom_val DECIMAL(5, 0)
    COMMENT '[MARM-UMREZ] Numerator for alternative uom to buom conversion factor'
    , denominator_alt_uom_buom_val DECIMAL(5, 0)
    COMMENT '[MARM-UMREN] Denominator for alternative uom to buom conversion factorr'
) USING DELTA
COMMENT 'Temporary data with alternative units of measure for products'
LOCATION '$location/PROD_ALT_UOM_SDIM';

DROP TABLE IF EXISTS $schema.shpmt_report_star;
CREATE TABLE IF NOT EXISTS $schema.shpmt_report_star (
    site_code STRING
    , site_name STRING
    , site_type_code STRING
    , site_type_desc STRING
    , company_code STRING
    , site_region_name STRING
    , site_region_short_name STRING
    , site_sub_region_name STRING
    , site_sub_region_short_name STRING
    , site_geoc_area_name STRING
    , site_geoc_area_short_name STRING
    , site_country_name STRING
    , site_country_code STRING
    , prod_id STRING
    , prod_name STRING
    , prod_subsector_name STRING
    , prod_subsector_id STRING
    , prod_categ_name STRING
    , prod_categ_id STRING
    , prod_tdcval_code STRING
    , prod_tdcval_desc STRING
    , freight_type_code STRING
    , fincl_cc_account_code STRING
    , base_uom STRING
    , shpmt_buom_qty DECIMAL(38, 10)
    , buom_su_factor DECIMAL(38, 10)
    , shpmt_su_qty DECIMAL(38, 10)
    , missing_alt_uom_g11_marm_flag STRING
    , missing_su_uom_g11_marm_flag STRING
    , last_update_utc_tmstp TIMESTAMP
    , cal_year_mth_num INT
) USING DELTA
PARTITIONED BY (cal_year_mth_num)
LOCATION '$location/SHPMT_REPORT_STAR';

DROP TABLE IF EXISTS $schema.shpmt_alt_uom_sfct;
CREATE TABLE IF NOT EXISTS $schema.shpmt_alt_uom_sfct (
    cal_year_mth_num INT
    COMMENT 'Calendar year & month of the data'
    , site_code STRING
    COMMENT '[LIPS-WERKS] or [Tvswz-WERKS] Site (plant) code'
    , prod_id STRING
    COMMENT '[LIPS-MATNR] Product (material) ID'
    , shpmt_alt_uom_qty DECIMAL(13, 3)
    COMMENT '[LIPS-LFIMG] Quantity of alternative uoms per site/product base on shipment data'
    , shpmt_alt_uom STRING
    COMMENT '[LIPS-VRKME] Name of the alternative uom'
    , base_uom STRING
    COMMENT '[MARA-MEINS]  Base Unit of Measure'
    , freight_type_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-FREIGHT_TYPE] SAP Sales order Freight Type. This classifies the sales order as:
    - C - Customer (sales to P&G external customer)
    - I - Intersite (internal sales to one of the P&G sites)
    - E - Export/Affiliate (sales to P&G contractor)'
    , dlvry_doc_num STRING
    COMMENT '[LIKP-VBELN]  Delivery document'
    , dlvry_item_num STRING
    COMMENT '[LIPS-POSNR]  Billing item'
    , order_doc_type_code STRING
    COMMENT '[VBAK-AUART]  Order type / [EKKO-BSART]  Purchasing Document Type'
    , sold_to_customer_id STRING
    COMMENT '[LIKP-KUNAG]  Sold-to party'
    , region_abbr_code STRING
    COMMENT 'Region abbreviation'
) USING DELTA
PARTITIONED BY (region_abbr_code)
COMMENT 'Temporary table with shipments(deliveries) detailed data'
LOCATION '$location/SHPMT_ALT_UOM_SFCT';

DROP TABLE IF EXISTS $schema.shpmt_sfct;
CREATE TABLE IF NOT EXISTS $schema.shpmt_sfct (
    cal_year_mth_num INT
    COMMENT 'Calendar year & month of the data'
    , site_code STRING
    COMMENT '[LIPS-WERKS] or [Tvswz-WERKS] Site (plant) code'
    , prod_id STRING
    COMMENT '[LIPS-MATNR] Product (material) ID'
    , base_uom STRING
    COMMENT '[MARA-MEINS]  Base Unit of Measure'
    , shpmt_buom_qty DECIMAL(38, 10)
    COMMENT 'Quantity of BUoM s per site/product base on shipment data'
    , buom_su_factor DECIMAL(38, 10)
    COMMENT 'Factor to convert from BUoM to SU of product'
    , shpmt_su_qty DECIMAL(38, 10)
    COMMENT 'Quantity of SUs per site/product base on shipment data. The value is obtained by multiplying SU conversion factor and buom quantity.'
    , freight_type_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-FREIGHT_TYPE] SAP Sales order Freight Type. This classifies the sales order as:
    - C - Customer (sales to P&G external customer)
    - I - Intersite (internal sales to one of the P&G sites)
    - E - Export/Affiliate (sales to P&G contractor)'
    , fincl_cc_account_code STRING
    COMMENT 'Financal cost center to which we apply the distribution cost center number'
    , missing_alt_uom_g11_marm_flag STRING
    COMMENT 'Is alternative unit of measure for product in G11 MARM table missing?'
    , missing_su_uom_g11_marm_flag STRING
    COMMENT 'Is SU unit of measure for product in G11 MARM table missing?'
    , generate_row_flag STRING
    COMMENT 'Is the row generated by the process? 
    For the correct operation of the AVERAGE exception we need to have exactly the same list of products in a group of site codes (legal entity). 
    That is the reason why we need to generate a row for a particular product and site and put there value 0 as shipment value.'
) USING DELTA
COMMENT 'Temporary table with shipments(deliveries) data (converted to BUoM and sumed)'
LOCATION '$location/SHPMT_SFCT';

DROP TABLE IF EXISTS $schema.shpmt_vol_reconciliation_report_star;
CREATE TABLE IF NOT EXISTS $schema.shpmt_vol_reconciliation_report_star (
    site_code STRING
    COMMENT '[LIPS-WERKS] or [Tvswz-WERKS] Site (plant) code'
    , site_name STRING
    COMMENT '[T001W-NAME1] Site (plant) name'
    , site_type_code STRING
    COMMENT '[T001W-ZZSITETYPC] Site (plant) type'
    , site_type_desc STRING
    COMMENT 'Site (plant) type description'
    , company_code STRING
    COMMENT '[T001K-BUKRS] Company code'
    , site_region_name STRING
    COMMENT 'Site (plant) region name '
    , site_region_short_name STRING
    COMMENT 'Site (plant) region short name '
    , site_sub_region_name STRING
    COMMENT 'Site (plant) sub region name '
    , site_sub_region_short_name STRING
    COMMENT 'Site (plant) sub region short name '
    , site_geoc_area_name STRING
    COMMENT 'Site (plant) geographic area name '
    , site_geoc_area_short_name STRING
    COMMENT 'Site (plant) geographic area short name '
    , site_country_name STRING
    COMMENT 'Site (plant) country name'
    , site_country_code STRING
    COMMENT '[T001W-LAND1 Site (plant) country code'
    , prod_id STRING
    COMMENT '[LIPS-MATNR] Product (material) ID'
    , prod_name STRING
    COMMENT 'Product (material) name'
    , prod_subsector_name STRING
    COMMENT 'Subsector name'
    , prod_subsector_id STRING
    COMMENT 'Subsector ID'
    , prod_categ_name STRING
    COMMENT 'Category name'
    , prod_categ_id STRING
    COMMENT 'Category ID'
    , prod_tdcval_code STRING
    COMMENT 'TDCVal code'
    , prod_tdcval_desc STRING
    COMMENT 'TDCVal description'
    , freight_type_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-FREIGHT_TYPE] SAP Sales order Freight Type. This classifies the sales order as:
    - C - Customer (sales to P&G external customer)
    - I - Intersite (internal sales to one of the P&G sites)
    - E - Export/Affiliate (sales to P&G contractor)'
    , fincl_cc_account_code STRING
    COMMENT 'Financial cost center to which we apply the distribution cost center number'
    , base_uom STRING
    COMMENT '[MARA-MEINS]  Base Unit of Measure'
    , shpmt_buom_qty DECIMAL(38, 10)
    COMMENT 'Quantity of BUOMs per site/product (PK) base on shipment data.
    The value is obtained from shpmt_report_star and modified base on algorithm from site_metadata_lkp'
    , buom_su_factor DECIMAL(38, 10)
    COMMENT 'Factor to convert from BUoM to SU of product'
    , shpmt_su_qty DECIMAL(38, 10)
    COMMENT 'Quantity of Sus per site/product (PK) base on shipment data. The value is obtained by multiplying SU conversion factor and buom quantity.
    The value is obtained from shpmt_report_star and modified base on algorithm from site_metadata_lkp'
    , last_update_utc_tmstp TIMESTAMP
    COMMENT 'BigData Calculated field: Time Stamp of table row modification operation in'
    , cal_year_mth_num INT
    COMMENT 'Calendar year & last month of the data'
) USING DELTA
PARTITIONED BY (cal_year_mth_num)
COMMENT 'Volume Reconciliation - shipment data aggregation based on defined business logic. 
This report is used for cost reconciliation based on shipment volume. 
This is also basis for SAP Hana R4 """"Artemis"""" upload template, which is used for Financial & Accounting purposes'
LOCATION '$location/SHPMT_VOL_RECONCILIATION_REPORT_STAR';

DROP TABLE IF EXISTS $schema.shpmt_vol_reconciliation_sstar;
CREATE TABLE IF NOT EXISTS $schema.shpmt_vol_reconciliation_sstar (
    `cal_year_mth_num` INT
    COMMENT 'Calendar year & last month of the data'
    , site_code STRING
    COMMENT '[LIPS-WERKS] or [Tvswz-WERKS] Site (plant) code'
    , site_name STRING
    COMMENT '[T001W-NAME1] Site (plant) name'
    , site_type_code STRING
    COMMENT '[T001W-ZZSITETYPC] Site (plant) type'
    , site_type_desc STRING
    COMMENT 'Site (plant) type description'
    , company_code STRING
    COMMENT '[T001K-BUKRS] Company code'
    , site_region_name STRING
    COMMENT 'Site (plant) region name '
    , site_region_short_name STRING
    COMMENT 'Site (plant) region short name '
    , site_sub_region_name STRING
    COMMENT 'Site (plant) sub region name '
    , site_sub_region_short_name STRING
    COMMENT 'Site (plant) sub region short name '
    , site_geoc_area_name STRING
    COMMENT 'Site (plant) geographic area name '
    , site_geoc_area_short_name STRING
    COMMENT 'Site (plant) geographic area short name '
    , site_country_name STRING
    COMMENT 'Site (plant) country name'
    , site_country_code STRING
    COMMENT '[T001W-LAND1 Site (plant) country code'
    , prod_id STRING
    COMMENT '[LIPS-MATNR] Product (material) ID'
    , prod_name STRING
    COMMENT 'Product (material) name'
    , prod_subsector_name STRING
    COMMENT 'Subsector name'
    , prod_subsector_id STRING
    COMMENT 'Subsector ID'
    , prod_categ_name STRING
    COMMENT 'Category name'
    , prod_categ_id STRING
    COMMENT 'Category ID'
    , prod_tdcval_code STRING
    COMMENT 'TDCVal code'
    , prod_tdcval_desc STRING
    COMMENT 'TDCVal description'
    , freight_type_code STRING
    COMMENT '[ZVXX_TMS1_COSTAL-FREIGHT_TYPE] SAP Sales order Freight Type. This classifies the sales order as:
    - C - Customer (sales to P&G external customer)
    - I - Intersite (internal sales to one of the P&G sites)
    - E - Export/Affiliate (sales to P&G contractor)'
    , fincl_cc_account_code STRING
    COMMENT 'Financial cost center to which we apply the distribution cost center number'
    , base_uom STRING
    COMMENT '[MARA-MEINS]  Base Unit of Measure'
    , shpmt_buom_qty DECIMAL(38, 10)
    COMMENT 'Quantity of BUOMs per site/product (PK) base on shipment data.
    The value is obtained from shpmt_report_star and modified base on algorithm from site_metadata_lkp'
    , buom_su_factor DECIMAL(38, 10)
    COMMENT 'Factor to convert from BUoM to SU of product'
    , shpmt_su_qty DECIMAL(38, 10)
    COMMENT 'Quantity of Sus per site/product (PK) base on shipment data. 
    The value is obtained by multiplying SU conversion factor and buom quantity.
    The value is obtained from shpmt_report_star and modified base on algorithm from site_metadata_lkp'
    , calc_type_code STRING
    COMMENT 'Calculation type code'
) USING DELTA
PARTITIONED BY (calc_type_code)
COMMENT 'Volume Reconciliation - shipment data aggregation based on defined business logic. 
This report is used for cost reconciliation based on shipment volume. 
This is also basis for SAP Hana R4 """"Artemis"""" upload template, which is used for Financial & Accounting purposes'
LOCATION '$location/SHPMT_VOL_RECONCILIATION_SSTAR';

CREATE TABLE IF NOT EXISTS $schema.pallet_alloc_site_type_dim (
    site_type_code STRING COMMENT 'Site (plant) type code'
    , site_type_desc STRING COMMENT 'Description of the site type'
) USING DELTA
COMMENT 'This is static table'
LOCATION '$location/pallet_alloc_site_type_dim';
