from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession


def get_spark() -> SparkSession:
    """
    Locate/Create a sparksession using databricks-connect if local, or sparksession if in
    """
    # yes this is ugly, yes this is how databricks cli repo recommends doing it
    try:
        from databricks.connect import DatabricksSession

        return DatabricksSession.builder.getOrCreate()
    except ImportError:
        return SparkSession.builder.getOrCreate()


def get_dbutils() -> DBUtils:
    spark = get_spark()
    return DBUtils(spark)
