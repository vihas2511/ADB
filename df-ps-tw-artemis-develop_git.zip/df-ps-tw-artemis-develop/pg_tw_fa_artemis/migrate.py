import logging

from pg_composite_pipelines_configuration.configuration import Configuration
from pg_composite_pipelines_migration.migration import Migration

from pg_tw_fa_artemis.common import get_dbutils, get_spark


def migrate():
    # bump log level up to info to improve CI/CD output
    logging.basicConfig()
    logging.getLogger().setLevel(logging.INFO)

    dbutils = get_dbutils()
    config = Configuration.load_for_default_environment(__file__, dbutils)
    schema = f"{config['catalog-name']}.{config['schema-name']}"
    storage_location = f"abfss://{config['storage']['container-name']}@{config['storage']['account-name']}.dfs.core.windows.net/{config['storage']['folder']}"
    Migration.migrate(
        "pg_tw_fa_artemis/silver_ps_artemis/ddl", schema, storage_location
    )


def demigrate():
    # this method will convert an existing schema into .sql migration files
    dbutils = get_dbutils()
    config = Configuration.load_for_default_environment(__file__, dbutils)
    schema = f"{config['catalog-name']}.{config['schema-name']}"
    Migration.demigrate_to_sql_files(f"{schema}.*", "pg_tw_fa_artemis")


if __name__ == "__main__":
    migrate()
