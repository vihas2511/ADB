#!/usr/bin/env python
# -*- coding: utf-8 -*-


def get_pass(pass_file_path):
    """Acquire encrypted password.

    For solutions implemented on BU you cannot keep saved passwords in plain text.
    Current approved solution is to use special java decryptor class.

    Attention:
        To get it work you need `decryptor.jar` or `encdec.jar`.
        You have to pass additional parameters in `spark-submit` call:

        $ spark2-submit --jars decryptor.jar [...]

    """
    from py4j.java_gateway import java_import

    jvm = sc._gateway.jvm  # noqa: F821
    java_import(jvm, "com.pg.biguniverse.security.Decryptor")
    passw = jvm.com.pg.biguniverse.security.Decryptor().loadPassword(pass_file_path)
    if not passw:
        raise Exception(
            "Decryption not possible! Different algorithm or currupted file!"
        )
    return passw
