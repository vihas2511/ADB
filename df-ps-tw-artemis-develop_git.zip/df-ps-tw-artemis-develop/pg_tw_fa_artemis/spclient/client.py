#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pulling files from the MS Sharepoint.

Example:
    Examples can be given using either the ``Example`` or ``Examples``
    sections. Sections support any reStructuredText formatting, including
    literal blocks:

    .. code-block:: sh

        pip install --user virtualenv
        python -m virtualenv venv
        source venv/bin/python
        pip install -r requirements.txt
        python

    .. code-block:: python

        from spclient import *
        c = SPClient('zenek', 'martyniuk_haslo_encrypted',
                     edge_point=https://pgone.sharepoint.com/,
                     site='sites/S2PAnalytics')
        client.load_file('path_relative_to_the_site', download=True)
"""

import abc
import errno
import io
import json
import logging
import os
import shutil

try:
    from urlparse import urljoin
except ImportError:
    from urllib.parse import urljoin

import requests

try:
    from urllib3.util.retry import Retry
except ImportError:
    from requests.packages.urllib3.util.retry import Retry

from .auth import OAuth, SAMLAuth


class SPClientError(Exception):
    def __init__(self, message="", extra=None):
        super(SPClientError, self).__init__(message)

        logger = logging.getLogger(self.__class__.__name__)
        logger.error(message)

        if extra:
            try:
                extra = json.loads(extra)
                message = "%s:\n%s" % (
                    message,
                    json.dumps(extra, indent=2, sort_keys=True),
                )
            except Exception as err:
                logger.debug(err)


class Client(object):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def load_file(self, rel_path, download=False, target_dir=None):
        raise NotImplementedError("Downloading files is the whole clue!")

    @abc.abstractmethod
    def get_file_property(self, rel_path, prop="TimeLastModified"):
        raise NotImplementedError("Getting file properties not implemented!")


class SPClient(Client):

    def __init__(
        self,
        username,
        password,
        edge_point="https://pgone.sharepoint.com",
        site="sites/S2PAnalytics",
        tenant_id=None,
        timeout=10,
        retries=3,
        backoff_factor=0.5,
        proxies=None,
        use_pg_gcp_proxy=False,
    ):

        self.logger = logging.getLogger(self.__class__.__name__)

        proxy = (
            proxies
            or (
                {
                    "http": "http://proxy.dbce-utils.gcp.pgcloud.com:8080",
                    "https": "http://proxy.dbce-utils.gcp.pgcloud.com:8080",
                }
                if use_pg_gcp_proxy
                else None
            )
            or {}
        )

        self.timeout = timeout
        s = requests.Session()
        s.proxies.update(proxy)

        retry = Retry(total=retries, backoff_factor=backoff_factor)
        adapter = requests.adapters.HTTPAdapter(max_retries=retry)
        s.mount("http://", adapter)
        s.mount("https://", adapter)
        if not tenant_id:
            s.auth = SAMLAuth(edge_point, username, password, proxies=proxy)
        else:
            s.auth = OAuth(
                edge_point,
                client_id=username,
                client_secret=password,
                tenant_id=tenant_id,
                proxies=proxy,
            )

        self.edge_point = edge_point
        self.site = site
        self.url = urljoin(edge_point, site)
        self.api = self.url + "/_api/web/%(f)s"
        self.api_ctxinfo = self.url + "/_api/contextinfo"
        self._s = s

        # aliases
        self.download = self.load_file
        self.scan = self.ls

    @property
    def session(self):
        return self._s

    def ls(
        self,
        directory="Shared Documents",
        max_lvl=1,
        attributes=None,
        orderby="name asc",
        where=None,
        top=None,
        filter_dirs=True,
        filter_files=True,
        flatten=False,
        show_dirs=True,
        show_files=True,
    ):
        """Scans folders and files.

        Args:
            directory (str): server relative path of folder to be scanned
            max_lvl (int, optional): how deep the scan should be performed
            attributes (str or list of str, optional): scanned property of the folder/file
            orderby (str or list of str, optional): attributes with additional `desc` or `asc` tag to perform ordering;
                sorting is done on each level of the tree separatly; more than one key is supported
            where (str, optional): query to filter the returned dataset
            top (int, optional): the number of records to return
            filter_dirs (bool, opional): flag to apply *where* for directiories
            filter_files (bool, opional): flag to apply *where* for files
            flatten (bool, optional): convert nested result into a plain list
            show_dirs (bool, optional): show in flattened result only directiories
            show_files (bool, optional): show in flattened result only files

        Note:
            Here you will find all of `supported attributes <https://docs.microsoft.com/en-us/previous-versions/office/sharepoint-csom/ee542189(v%3Doffice.15)>`_.
            How to filter/build *where* query, `read this <https://www.odata.org/documentation/odata-version-2-0/uri-conventions/#FilterSystemQueryOption>`_.

        Returns:
            dict: simple or nested structure of the scanned folder
        """
        if flatten and not (show_dirs or show_files):
            return []
        if not directory:
            raise ValueError('"directory" have to be a string!')
        if max_lvl > 2:
            self.logger.warning(
                'Scaning folder structure for "max_lvl>2" may be insanely slow!'
            )
        if not orderby:
            orderby = []
        if orderby and not isinstance(orderby, (tuple, list)):
            orderby = [orderby]
        if not attributes:
            attributes = []
        if not isinstance(attributes, (tuple, list)):
            attributes = [attributes]
        attributes = list(
            set(
                map(
                    lambda i: i.replace(" desc", "").replace(" asc", "").lower(),
                    (["name"] + attributes + orderby),
                )
            )
        )

        def url_builder(directory, qtype="Folders", where_flag=True):
            f = "getfolderbyserverrelativeurl('%s')/%s?$select=%s" % (
                directory,
                qtype,
                ",".join(attributes),
            )
            if orderby:
                f += "&$orderby=%s" % ",".join(orderby)
            if where and isinstance(where, str) and where_flag:
                f += "&$filter=%s" % where
            if top and isinstance(top, int) and where_flag:
                f += "&$top=%s" % top
            return self.api % dict(f=f)

        def item_builder(i, is_file=True):
            # cumbersome dict merging due to py2 and py3 incompatybilities
            return {
                k.lower(): v
                for k, v in dict(
                    list(i.items()) + list({"is_file": is_file}.items())
                ).items()
                if k.lower() in attributes + ["is_file"]
            }

        def walk(directory, attributes, lvl):
            lvl += 1

            r = self._s.get(
                url_builder(directory, "Folders", filter_dirs), timeout=self.timeout
            )
            if r.status_code != 200:
                raise SPClientError(extra=r.text)
            result = [item_builder(i, False) for i in r.json()["value"]]

            if lvl < max_lvl:
                for i, d in enumerate(result):
                    result[i]["children"] = walk(
                        os.path.join(directory, d["name"]), attributes, lvl
                    )

            r = self._s.get(
                url_builder(directory, "Files", filter_files), timeout=self.timeout
            )
            if r.status_code != 200:
                raise SPClientError(extra=r.text)
            result = result + [item_builder(i, True) for i in r.json()["value"]]

            return result

        def _flatten(el):
            for i in el:
                if "children" in i.keys():
                    c = i.pop("children")
                    el = el + _flatten(c)
            l1 = []
            l2 = []
            if show_dirs:
                l1 = [i for i in el if i["is_file"] == False]
            if show_files:
                l2 = [i for i in el if i["is_file"] == True]
            return l1 + l2

        result = walk(directory, attributes, 0)
        if flatten:
            return _flatten(result)
        else:
            return result

    def get_digest(self):
        return self._s.post(self.api_ctxinfo, timeout=self.timeout).json()[
            "FormDigestValue"
        ]

    def load_directory(
        self,
        rel_path,
        target_dir="download",
        clear_target_dir=True,
        max_connections=10,
        max_lvl=1,
        where=None,
        filter_dirs=True,
        filter_files=True,
    ):
        """Downloads a directory from MS Sharepoint into local fs (currently there is no option to load all the files into memory).

        Args:
            rel_path (str): server relative path of directory to be downloaded
            download (bool, optional): download and save to file instead of storing in a buffer (currenlty only saving ot local fs is enabled)
            target_dir (str, optional): target folder on the server
            clear_target_dir (str, optional): clear target directory before saving new files
            max_lvl (int, optional): how deep the scan should be performed

        Returns:
            :obj:`io.BytesIO`: buffer or *None* (when saved into fs)
        """
        metadata = self.ls(
            rel_path,
            attributes="ServerRelativePath",
            max_lvl=max_lvl,
            where=where,
            filter_dirs=filter_dirs,
            filter_files=filter_files,
            flatten=True,
            show_dirs=False,
            show_files=True,
        )
        if target_dir and clear_target_dir:
            try:
                shutil.rmtree(target_dir)
            except EnvironmentError:
                self.logger.warning("%s path does not exist", target_dir)
            os.makedirs(target_dir)

        def load(i):
            remote_path = (
                i["serverrelativepath"]["DecodedUrl"]
                .replace(self.site, "")
                .strip("/")
                .strip("\\")
            )
            local_path = os.path.join(
                target_dir, remote_path.replace(rel_path, "").strip("/").strip("\\")
            )

            self.logger.debug(
                "remote_path: %s, local_path: %s", remote_path, local_path
            )
            try:
                os.makedirs(os.path.dirname(local_path))
            except OSError as err:
                if err.errno == errno.EEXIST:
                    pass
                else:
                    raise
            self.load_file(remote_path, download=True, target_path=local_path)
            self.logger.info(
                'File "%s" downloaded [*%s]',
                os.path.split(remote_path)[1],
                os.path.splitext(remote_path)[1],
            )

        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed

            with ThreadPoolExecutor(max_connections) as exe:
                futures = [exe.submit(load, i) for i in metadata]
                for future in as_completed(futures):
                    future.result()
        except ImportError:
            self.logger.warning(
                "Paralell download not supported. One download at a time."
            )
            _ = [load(i) for i in metadata]

    def load_file(
        self,
        rel_path,
        download=False,
        target_dir="",
        target_filename=None,
        target_path=None,
        as_binary=True,
    ):
        """Downloads a file from MS Sharepoint into local fs or/and file-like-object.

        Args:
            rel_path (str): server relative path of file to be downloaded
            download (bool, optional): download and save to file instead of storing in a buffer
            target_dir (str, optional): target folder on the server
            target_filename (str, optional): filename of the target file on the server, if *None*
                source filename will be used.
            target_path (str, optional): overrides *target_dir& and *target_filename*; alternative way
                to define path on remote server.
            as_binary (bool, optional): `True` - return `io.BytesIO`, `False` - return `io.StringIO`

        Returns:
            :obj:`io.IOBase`: buffer or *None* (when saved into file)
        """
        folder, doc = os.path.split(rel_path)
        f = "GetFolderByServerRelativeUrl('%s')/Files('%s')/$value" % (folder, doc)
        doc = target_filename or doc
        if target_path:
            target_dir, doc = os.path.split(target_path)
        url = self.api % dict(f=f)

        r = self._s.get(url, stream=True, timeout=self.timeout)
        if r.status_code != 200:
            raise SPClientError(extra=r.text)
        if target_dir != "" and not os.path.exists(target_dir):
            os.makedirs(target_dir)
        if download:
            with open(os.path.join(target_dir, os.path.basename(doc)), "wb") as f:
                shutil.copyfileobj(r.raw, f)
        else:
            return io.BytesIO(r.content) if as_binary else io.StringIO(r.text)

    def load_list(self, list_name, top=1000):
        """Gets all the items of the remote list by the list name.

        Args:
            list_name (str): name of the list to be downloaded

        Returns:
            :obj:`io.StringIO`: list contents as a string

        """

        f = "lists/GetByTitle('%s')/items?$skiptoken=Paged=TRUE&$top=%s" % (
            list_name,
            top,
        )
        url = self.api % dict(f=f)
        res = []

        while url:
            r = self._s.get(url, timeout=self.timeout)
            try:
                _ = list(res.append(d) for d in r.json()["value"])
            except KeyError:
                raise Exception(r.json())

            try:
                url = r.json()["odata.nextLink"]
            except KeyError:
                url = None

        return res

    def create_folder(self, rel_path):
        """Creates a folder in MS Sharepoint.

        Args:
            rel_path (str): server relative path to folder/file to be deleted
        """
        f = "Folders/add('%s')" % rel_path
        url = self.api % dict(f=f)

        r = self._s.post(
            url, headers={"X-RequestDigest": self.get_digest()}, timeout=self.timeout
        )
        if r.status_code == 200:
            return r.json()
        else:
            raise SPClientError(extra=r.text)

    def save_file(self, src_path, tgt_path):
        """Uploads a file to a particular folder on MS Sharepoint.

        Args:
            src_path (str): path of to file to be uploaded
            trgt_path (str): complete path of the target file relative to the site

        Returns:
            str: error description or url to access the uploaded file
        """
        with open(src_path, "rb") as f:
            return self.save_stream(f, tgt_path)

    def save_stream(self, input_stream, tgt_path):
        """Uploads a file to a particular folder on MS Sharepoint.

        Args:
            input_stream (io.BaseIO): file like object
            trgt_path (str): complete path of the target file relative to the site

        Returns:
            str: error description or url to access the uploaded file
        """
        folder, doc = os.path.split(tgt_path)
        f = "GetFolderByServerRelativeUrl('%s')/Files/add(url='%s', overwrite=true)" % (
            folder,
            doc,
        )
        url = self.api % dict(f=f)

        headers = {
            "Accept": "application/json; odata=nometadata",
            "Content-Type": "application/octet-stream",
            "Content-Length": str(input_stream.seek(0, 2)),
            "X-RequestDigest": self.get_digest(),
        }

        input_stream.seek(0)
        r = self._s.post(url, data=input_stream, headers=headers, timeout=self.timeout)
        if r.status_code == 200:
            return r.json()["LinkingUri"]
        raise SPClientError(extra=r.text)

    def get_file_property(self, rel_path, prop="TimeLastModified"):
        """Gets properties of the remote file.

        Args:
            rel_path (str): relative remote path
            prop (str, optional): property to fetch

        Warning:
            To check directory, add "/" a the end of the *rel_path*.

        Note:
            Example properties:
            `Author`, `EffectiveInformationRightsManagementSettings`,
            `LockedByUser`, `ContentTag`, `UIVersion`, `ListItemAllFields`,
            `MinorVersion`, `VersionEvents`, `Versions`,
            `IrmEnabled`, `UIVersionLabel`, `Title`, `Properties`,
            `TimeLastModified`, `InformationRightsManagementSettings`,
            `Name`, `Level`, `CheckedOutByUser`, `CheckOutType`,
            `Length`, `ModifiedBy`, `UniqueId`, `MajorVersion`,
            `Exists`, `TimeCreated`, `LinkingUri`, `ServerRelativeUrl`,
            `CheckInComment`, `ETag`, `LinkingUrl`, `CustomizedPageStatus`

        Some of them are complex and demand additional queries.
        """
        return self._get_object_property("file", rel_path, prop)

    def get_list_property(self, list_name, prop="LastItemModifiedDate"):
        """AI is creating summary for get_list_property

        Args:
            list_name (str): SP list name
            prop (str, optional): property to fetch

        Note:
            Example properties:
            `NoCrawl`, `odata.type`, `ItemCount`, `ParentWebPath`, `ListExperienceOptions`,
            `MultipleDataList`, `IsApplicationList`, `DefaultItemOpenUseListSetting`,
            `EntityTypeName`, `AllowContentTypes`, `Created`, `LastItemModifiedDate`,
            `ServerTemplateCanCreateFolders`, `ParentWebUrl`, `IrmReject`, `EnableAttachments`,
            `DocumentTemplateUrl`, `ForceCheckout`, `ImagePath`, `TemplateFeatureId`, `IsCatalog`,
            `odata.metadata`, `IrmExpire`, `odata.editLink`, `ContentTypesEnabled`, `CurrentChangeToken`,
            `BaseTemplate`, `EnableFolderCreation`, `Direction`, `odata.id`, `MajorWithMinorVersionsLimit`,
            `CrawlNonDefaultViews`, `EnableRequestSignOff`, `Hidden`, `EnableMinorVersions`,
            `HasExternalDataSource`, `LastItemDeletedDate`, `Id`, `Title`, `ImageUrl`, `BaseType`,
            `EnableVersioning`, `ListItemEntityTypeFullName`, `IrmEnabled`, `DisableGridEditing`,
            `IsPrivate`, `EnableModeration`, `ParserDisabled`, `ExemptFromBlockDownloadOfNonViewableFiles`,
            `Description`, `DefaultContentApprovalWorkflowId`, `LastItemUserModifiedDate`,
            `DraftVersionVisibility`, `FileSavePostProcessingEnabled`, `odata.etag`, `MajorVersionLimit`

            More information can be obtained through the following link:
            https://docs.microsoft.com/en-us/sharepoint/dev/sp-add-ins/working-with-lists-and-list-items-with-rest
        """
        return self._get_object_property("list", list_name, prop)

    def _get_object_property(self, resource_type="file", object_path=None, prop=None):
        """AI is creating summary for _get_object_property

        Args:
            resource_type (str): resource type: 'file' or 'list'.
            object_path (str): path or object name.
            prop (str): property name to fetch.

        Returns:
            str: query content
        """
        if resource_type not in ["list", "file"]:
            raise ValueError('"list" or "file" resource_type is only supported.')
        if not object_path:
            raise ValueError('"object_path" needs to be provided based on a type.')

        if resource_type == "list":
            f = "lists/GetByTitle('%s')/%s" % (object_path, prop)
        else:
            folder, doc = os.path.split(object_path)
            if doc:
                f = "GetFolderByServerRelativeUrl('%s')/Files('%s')/%s" % (
                    folder,
                    doc,
                    prop,
                )
            else:
                f = "GetFolderByServerRelativeUrl('%s')/%s" % (folder, prop)

        url = self.api % dict(f=f)

        r = self._s.get(url, timeout=self.timeout)
        if r.status_code == 200:
            try:
                return self._s.get(url, timeout=self.timeout).json()["value"]
            except KeyError:
                return self._s.get(url, timeout=self.timeout).json()
        else:
            raise SPClientError(extra=r.text)

    def delete(self, rel_path):
        """Removes file or folder from MS Sharepoint.

        Note:
            To delete a file *zz* provide url: *"xx/yy/zz"*
            To delete folder *zz* provide url: *"xx/yy/zz/"*

            For some reason there is an odata report of *Unknown error*.
            Nevertheless if HTTP status code is *200* consider it to work!

        Args:
            rel_path (str): server relative path to folder/file to be deleted
        """
        folder, doc = os.path.split(rel_path)

        if doc:
            f = "GetFolderByServerRelativeUrl('%s')/Files('%s')" % (folder, doc)
        else:
            f = "GetFolderByServerRelativeUrl('%s')" % folder
        url = self.api % dict(f=f)

        headers = {"X-RequestDigest": self.get_digest(), "IF-MATCH": 'etag or "*"'}

        r = self._s.delete(url, headers=headers)
        if r.status_code == 200:
            return self._s.get(url, timeout=self.timeout).json()
        else:
            raise SPClientError(extra=r.text)

    def flatten_dict(self, input_dict, separator):
        """Flatten a dictionary. Recursive function

        Args:
            input_dict (dict): Dict to be flatten
            separator (str): separator for dictionary keys

        Returns:
            dict: flattened dict
        """
        local_dict = {}
        if type(input_dict) == dict:
            for key, value in list(input_dict.items()):
                if type(value) == dict:
                    value = self.flatten_dict(value, separator)
                    for n_key, n_value in value.items():
                        local_dict[key + separator + n_key] = n_value
                else:
                    local_dict[key] = value
        else:
            local_dict = dict(input_dict)
        return local_dict

    def download_directory(
        self, rel_path, target_dir="", clear_target_dir=True, max_lvl=1
    ):
        """Downloads a directory from MS Sharepoint into local fs.

        Args:
            rel_path (str): server relative path of directory to be downloaded
            target_dir (str, optional): target folder on the server
            clear_target_dir (str, optional): clear target directory before saving new files
            max_lvl (int, optional): how deep the scan should be performed

        """
        sp_dir_files_dict = self.ls(directory=rel_path, max_lvl=max_lvl)
        sp_files_flatten_dict = self.flatten_dict(sp_dir_files_dict, "/")
        if clear_target_dir:
            if (target_dir != "") & (len(target_dir) > 2):
                import os
                import shutil

                shutil.rmtree(target_dir)
                os.mkdir(target_dir)
            else:
                raise ValueError(
                    "Change the target dir, we cannot remove root directory"
                )
        for key, value in sp_files_flatten_dict.items():
            # Calculate the actual target_dir (with subdirectories)
            sp_adress_list = key.replace(rel_path, "").strip("/").split("/")
            # drop the file name
            del sp_adress_list[-1]
            calc_target_dir = target_dir.rstrip("/") + "/" + "/".join(sp_adress_list)
            # print (key, calc_target_dir)
            self.load_file(key, True, calc_target_dir)


class OfflineClient(Client):
    """For testing purposes mainly."""

    def __init__(self, *args, **kwargs):
        pass

    def load_file(self, rel_path, **kwargs):
        return os.path.basename(rel_path)

    def get_file_property(self, rel_path, prop="TimeLastModified"):
        from datetime import datetime

        return str(datetime.now())
