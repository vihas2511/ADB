SELECT
  shpmt_id as `Load ID`,
  dlvry_id as `Delivery ID`,
  tms_service_code as `Service TMS Code`,
  ship_cond_val as `Shipping Condition`,
  ship_cond_desc as `Shipping Conditions Description`,
  shpmt_start_date as `Actual Ship Date`,
  actual_goods_issue_date as `Actual Goods Issue Date`,
  to_utc_timestamp(from_unixtime(unix_timestamp()), 'UTC') as domo_extract_utc_tmstp
FROM
  {app_db_name}.vfr_data_hub_star
WHERE
  fiscal_year_num in {fiscal_year}
  and fiscal_year_perd_num in {fiscal_month}
  AND shpmt_start_date != '00/00/0000'
  AND actual_goods_issue_date != '00/00/0000'
  AND tms_service_code IS NOT NULL
  AND tms_service_code != '#'
  AND tms_service_code != ' '