'''Main pyspark job file. It redirects to a proper "load*" file based on
input parameters:
 - config_module - name of the config file, e.g. "odsspark_uat_config"
 - target_table - table name which should be loaded
 - debug_mode_ind - indicator enabling debug mode
'''
import os
import sys
from datetime import datetime
import logging

sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/shared/prod/code/python')
sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/transfix/code/python')

def main_argparse(args_lst):
    ''' Parse input parameters '''
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config_module", required=True)
    parser.add_argument("-t", "--target_table", required=True)
    parser.add_argument("-d", "--debug_mode_ind", required=False, type=int,
                        default=0)
    args = parser.parse_args(args=args_lst)
    return args


def main(args_lst):
    ''' Main '''

    # error codes for the metadata 
    fstar, rgvrs = 0, 0
    csot_star = 0
    iot_star, vfr_data_hub_star = 0, 0
    vfr_load_agg, weekly_network_sccrd_star = 0, 0
    weekly_network_sccrd_agg_star = 0
    on_time_data_hub_star, lot_star = 0, 0
    
    # error codes for the metadata, carrier tables  
    tac_shpmt_detail_star, tac_lane_detail_star = 0, 0
    tac_tender_summary_star, tfs_technical_name_star = 0, 0 
    tac_technical_name_star, tfs_subsector_cost_star = 0, 0 
    tac_tender_star, tfs_acsrl_star = 0, 0 
    api_fails = []

    try:
        args = main_argparse(args_lst)
        logging.basicConfig(stream=sys.stderr,
                            level=logging.ERROR if args.debug_mode_ind == 0
                            else logging.INFO,
                            format='%(levelname)s %(asctime)s %(funcName)s %(message)s',
                            datefmt='%m/%d/%Y %I:%M:%S %p')
        logging.info("Input param: config_module = {}".format(args.config_module))
        logging.info("Input param: target_table = {}".format(args.target_table))
        logging.info("Input param: debug_mode_ind = {}".format(args.debug_mode_ind))
        logging.debug("DEBUG = {}".format(args.debug_mode_ind))

        # 
        # Metadata part for star tables
        # 
        # from mdIntegration import md_integration_functions_transfix as mdi_exec, ps_mdi_transfix_config as conf
        from mdIntegration import md_integration_functions_transfix as mdi_exec
        from mdIntegration import transfix_config as conf

        if args.target_table == 'on_time_data_hub_star':
            from load_otd import load_on_time_data_hub_star as lotd
            lotd.load_on_time_data_hub_star(
                logging, args.config_module, args.debug_mode_ind, "_OTD_DATAHUB")

            on_time_data_hub_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "ON_TIME_DATA_HUB_STAR", '')

            if on_time_data_hub_star != 0:
                mdi_exec.publish_execution_to_metadata(on_time_data_hub_star, api_fails)  
        
        elif args.target_table == 'lot_star':
            from load_lot import load_lot_star as lot
            lot.load_lot_star(logging, args.config_module, args.debug_mode_ind, "_LOT")
            
            lot_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "LOT_STAR", '')

            if lot_star != 0:
                mdi_exec.publish_execution_to_metadata(lot_star, api_fails)
                
        elif args.target_table == 'fap_star':
            from load_fap import load_fap_star as fap
            fap.load_fap_star(logging, args.config_module, args.debug_mode_ind, "_FAP")

            fstar, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "FAP_STAR", '')
            
            if fstar != 0:
                mdi_exec.publish_execution_to_metadata(fstar, api_fails)
        elif args.target_table == 'carrier':
            from load_carrier import load_carrier as cd
            cd.load_carrier_dashboard(logging, args.config_module, args.debug_mode_ind, "_CARRIER")
            
            tac_shpmt_detail_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TAC_SHPMT_DETAIL_STAR", '')

            if tac_shpmt_detail_star != 0:
                mdi_exec.publish_execution_to_metadata(tac_shpmt_detail_star, api_fails)

            tac_lane_detail_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TAC_LANE_DETAIL_STAR", '')

            if tac_lane_detail_star != 0:
                mdi_exec.publish_execution_to_metadata(tac_lane_detail_star, api_fails)

            tac_tender_summary_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TAC_TENDER_SUMMARY_STAR", '')

            if tac_tender_summary_star  != 0:
                mdi_exec.publish_execution_to_metadata(tac_tender_summary_star, api_fails)

            tfs_technical_name_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TFS_TECHNICAL_NAME_STAR", '')

            if tfs_technical_name_star  != 0:
                mdi_exec.publish_execution_to_metadata(tfs_technical_name_star, api_fails)

            tac_technical_name_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TAC_TECHNICAL_NAME_STAR", '')

            if tac_technical_name_star != 0:
                mdi_exec.publish_execution_to_metadata(tac_technical_name_star, api_fails) 

            tfs_subsector_cost_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TFS_SUBSECTOR_COST_STAR", '')

            if tfs_subsector_cost_star != 0:
                mdi_exec.publish_execution_to_metadata(tfs_subsector_cost_star, api_fails)

            tac_tender_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TAC_TENDER_STAR", '')

            if tac_tender_star != 0:
                mdi_exec.publish_execution_to_metadata(tac_tender_star, api_fails)

            tfs_acsrl_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "TFS_ACSRL_STAR", '')

            if tfs_acsrl_star != 0:
                mdi_exec.publish_execution_to_metadata(tfs_acsrl_star, api_fails)                      

        elif args.target_table == 'csot_star':
            from load_csot import load_csot_star as csot
            csot.load_csot_star(logging, args.config_module, args.debug_mode_ind, "_CSOT")
            
            csot_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "CSOT_STAR", '')

            if csot_star != 0:
                mdi_exec.publish_execution_to_metadata(csot_star, api_fails)

        elif args.target_table == 'iot_star':
            from load_iot import load_iot_star as iot
            iot.load_iot_star(logging, args.config_module, args.debug_mode_ind, "_IOT")
           
            iot_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "IOT_STAR", '')

            if iot_star != 0:
                mdi_exec.publish_execution_to_metadata(iot_star, api_fails)

        elif args.target_table == 'vfr_data_hub_star':
            from load_vfr import load_vfr_data_hub_star as vfr
            vfr.load_vfr_data_hub_star(logging, args.config_module, args.debug_mode_ind, "_VFR")

            vfr_data_hub_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "VFR_DATA_HUB_STAR", '')

            if vfr_data_hub_star != 0:
                mdi_exec.publish_execution_to_metadata(vfr_data_hub_star, api_fails)

        elif args.target_table == 'vfr_load_agg':
            from load_vfr_us_ca import load_vfr_us_ca_star as vfr_us_ca
            vfr_us_ca.load_vfr_us_ca_star(logging, args.config_module, args.debug_mode_ind, "_VFR_US_CA")
            
            vfr_load_agg, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "VFR_LOAD_AGG_STAR", '')

            if vfr_load_agg != 0:
                mdi_exec.publish_execution_to_metadata(vfr_load_agg, api_fails)            

        elif args.target_table == 'rgvr_star':
            from load_rgvr import load_rgvr_star as rgvr
            rgvr.load_rgvr(logging, args.config_module, args.debug_mode_ind, "_RGVR")
 
            rgvrs, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "RGVR_STAR", '')

            if rgvrs != 0:
                mdi_exec.publish_execution_to_metadata(rgvrs, api_fails)
            
        elif args.target_table == 'weekly_network_sccrd_star':
            from load_netw_scorec import load_network_scorecard as ns
            ns.load_network_scorecard(logging, args.config_module, args.debug_mode_ind, "_NS")
            
            weekly_network_sccrd_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "WEEKLY_NETWORK_SCCRD_STAR", '')
            
            if weekly_network_sccrd_star != 0:
                mdi_exec.publish_execution_to_metadata(weekly_network_sccrd_star, api_fails)        
        
        elif args.target_table == 'weekly_network_sccrd_agg_star':
            from load_netw_scorec import load_network_scorecard2 as ns2
            ns2.load_network_scorecard(logging, args.config_module, args.debug_mode_ind, "_NS")
            
            weekly_network_sccrd_agg_star, api_fails = mdi_exec.cdl_metadata_start_execution("Transfix", '', conf.CONTAINER_URL, conf.TABLE_PATH_PREFIX, "WEEKLY_NETWORK_SCCRD_AGG_STAR", '')
        
            if weekly_network_sccrd_agg_star != 0:
                mdi_exec.publish_execution_to_metadata(weekly_network_sccrd_agg_star, api_fails)               
        
        elif args.target_table == 'test':
            from test import load_test as ts
            ts.load_test(logging, args.config_module, args.debug_mode_ind, "_TEST")
        elif args.target_table == 'wait_for_cluster':
            pass
        else:
            logging.error("Unknown target table {}".format(args.target_table))
            sys.exit(1)

        # end of metadata part 

        logging.info("Execution ended")

    except Exception as exception:

        # if datapipe fails, publish the failed run in the metadata      
        api_fails.append(["Exception during datepipe Transfix, exception: {}".format(exception)])  

        if fstar != 0:
            mdi_exec.publish_execution_to_metadata(fstar, api_fails)
        if rgvrs != 0:
            mdi_exec.publish_execution_to_metadata(rgvrs, api_fails)
        if csot_star != 0:
            mdi_exec.publish_execution_to_metadata(csot_star, api_fails)
        if iot_star != 0:
            mdi_exec.publish_execution_to_metadata(iot_star, api_fails)
        if vfr_data_hub_star != 0:
            mdi_exec.publish_execution_to_metadata(vfr_data_hub_star, api_fails)
        if vfr_load_agg != 0:
            mdi_exec.publish_execution_to_metadata(vfr_load_agg, api_fails)
        if weekly_network_sccrd_star != 0:
            mdi_exec.publish_execution_to_metadata(weekly_network_sccrd_star, api_fails)
        if weekly_network_sccrd_agg_star != 0:
            mdi_exec.publish_execution_to_metadata(weekly_network_sccrd_agg_star, api_fails)
        if on_time_data_hub_star != 0:
            mdi_exec.publish_execution_to_metadata(on_time_data_hub_star, api_fails)
        if lot_star != 0:
            mdi_exec.publish_execution_to_metadata(lot_star, api_fails)
        if tac_shpmt_detail_star != 0:
            mdi_exec.publish_execution_to_metadata(tac_shpmt_detail_star, api_fails)
        if tac_lane_detail_star != 0:
            mdi_exec.publish_execution_to_metadata(tac_lane_detail_star, api_fails)
        if tac_tender_summary_star != 0:
            mdi_exec.publish_execution_to_metadata(tac_tender_summary_star, api_fails)
        if tfs_technical_name_star  != 0:
            mdi_exec.publish_execution_to_metadata(tfs_technical_name_star, api_fails)
        if tac_technical_name_star != 0:
            mdi_exec.publish_execution_to_metadata(tac_technical_name_star, api_fails)
        if tfs_subsector_cost_star  != 0:
            mdi_exec.publish_execution_to_metadata(tfs_subsector_cost_star, api_fails)
        if tac_tender_star != 0:
            mdi_exec.publish_execution_to_metadata(tac_tender_star, api_fails)
        if tfs_acsrl_star != 0:
            mdi_exec.publish_execution_to_metadata(tfs_acsrl_star, api_fails) 
                    
        print("exception: {} at {}".format(type(exception), datetime.now()))
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logging.error(exception)
        sys.stdout.flush()
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv[1:])
