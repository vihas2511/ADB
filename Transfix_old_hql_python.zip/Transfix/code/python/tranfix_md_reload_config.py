''' Configuration file '''

#### Spark parameters
#SPARK_MASTER = 'local[4]'
SPARK_MASTER = 'yarn'
NUM_EXECUTORS = 8

##### DB connection parameters
HIVE_PARAMETERS = {
    'database': 'ap_transfix_tv_na',
	'dbTransVsbltBw': 'dp_trans_vsblt_bw',
    'dbMasterDataG11': 'dp_masterdata_g11',
    'dbPrdMasterDataG11': 'dp_masterdata_g11',
    'dbOsiNa': 'dp_osi_na_ecc',
    'dbOsiNaUat': 'dp_osi_na_ecc',
    'dbRds': 'rds',
    'dbDirectShpmtCfr': 'dp_direct_shpmt_cfr'
}

###
HIVE_SCRIPT_DIR_PATH="dbfs:/mnt/dppsdatahubx45bab07e/etl/transfix/code/hive"

HQLS_ORDERED_LIST = {
        'customer_hier656': 'customer_hier656_na.hql',
        'customer': 'customer_na.hql',
        'plant': 'plant_na.hql',
        'product1': 'product1_na.hql',
        'sales_org': 'sales_org_na.hql',
        'shipping_point': 'shipping_point_na.hql',
        'storage_location': 'storage_location_na.hql',
        'vendor': 'vendor_na.hql'
}

