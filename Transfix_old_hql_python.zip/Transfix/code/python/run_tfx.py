import sys
sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/transfix/code/python')
import runSparkSql as m
import utils

sys.argv = ['-ctranfix_reload_config']
reload(m)
reload(utils)
m.main(sys.argv)
