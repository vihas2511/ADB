'''Main pyspark job file. It redirects to a proper "load*" file based on
input parameters:
 - config_module - name of the config file, e.g. "odsspark_uat_config"
 - target_table - table name which should be loaded
 - debug_mode_ind - indicator enabling debug mode
'''
import os
import sys
from datetime import datetime
import logging

sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/shared/prod/code/python')
sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/transfix/code/python')


def main_argparse(args_lst):
    ''' Parse input parameters '''
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config_module", required=True)
    parser.add_argument("-t", "--target_table", required=True)
    parser.add_argument("-d", "--debug_mode_ind", required=False, type=int,
                        default=0)
    args = parser.parse_args(args=args_lst)
    return args


def main(args_lst):
    ''' Main '''
    try:
        args = main_argparse(args_lst)
        logging.basicConfig(stream=sys.stderr,
                            level=logging.ERROR if args.debug_mode_ind == 0
                            else logging.INFO,
                            format='%(levelname)s %(asctime)s %(funcName)s %(message)s',
                            datefmt='%m/%d/%Y %I:%M:%S %p')
        logging.info("Input param: config_module = {}".format(args.config_module))
        logging.info("Input param: target_table = {}".format(args.target_table))
        logging.info("Input param: debug_mode_ind = {}".format(args.debug_mode_ind))
        logging.debug("DEBUG = {}".format(args.debug_mode_ind))

        if args.target_table == 'on_time_data_hub_star':
            from load_otd import load_on_time_data_hub_star as lotd
            lotd.load_on_time_data_hub_star(
                logging, args.config_module, args.debug_mode_ind, "_OTD_DATAHUB")
        elif args.target_table == 'lot_star':
            from load_lot import load_lot_star as lot
            lot.load_lot_star(logging, args.config_module, args.debug_mode_ind, "_LOT")
        elif args.target_table == 'fap_star':
            from load_fap import load_fap_star as fap
            fap.load_fap_star(logging, args.config_module, args.debug_mode_ind, "_FAP")
        elif args.target_table == 'carrier':
            from load_carrier import load_carrier as cd
            cd.load_carrier_dashboard(logging, args.config_module, args.debug_mode_ind, "_CARRIER")
        elif args.target_table == 'csot_star':
            from load_csot import load_csot_star as csot
            csot.load_csot_star(logging, args.config_module, args.debug_mode_ind, "_CSOT")
        elif args.target_table == 'iot_star':
            from load_iot import load_iot_star as iot
            iot.load_iot_star(logging, args.config_module, args.debug_mode_ind, "_IOT")
        elif args.target_table == 'vfr_data_hub_star':
            from load_vfr import load_vfr_data_hub_star as vfr
            vfr.load_vfr_data_hub_star(logging, args.config_module, args.debug_mode_ind, "_VFR")
        elif args.target_table == 'vfr_load_agg':
            from load_vfr_us_ca import load_vfr_us_ca_star as vfr_us_ca
            vfr_us_ca.load_vfr_us_ca_star(logging, args.config_module, args.debug_mode_ind, "_VFR_US_CA")
        elif args.target_table == 'rgvr_star':
            from load_rgvr import load_rgvr_star as rgvr
            rgvr.load_rgvr(logging, args.config_module, args.debug_mode_ind, "_RGVR")
        elif args.target_table == 'weekly_network_sccrd_star':
            from load_netw_scorec import load_network_scorecard as ns
            ns.load_network_scorecard(logging, args.config_module, args.debug_mode_ind, "_NS")
        elif args.target_table == 'weekly_network_sccrd_agg_star':
            from load_netw_scorec import load_network_scorecard2 as ns2
            ns2.load_network_scorecard(logging, args.config_module, args.debug_mode_ind, "_NS")
        elif args.target_table == 'test':
            from test import load_test as ts
            ts.load_test(logging, args.config_module, args.debug_mode_ind, "_TEST")
        elif args.target_table == 'wait_for_cluster':
            pass
        else:
            logging.error("Unknown target table {}".format(args.target_table))
            sys.exit(1)

        logging.info("Execution ended")

    except Exception as exception:
        print("exception: {} at {}".format(type(exception), datetime.now()))
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logging.error(exception)
        sys.stdout.flush()
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv[1:])
