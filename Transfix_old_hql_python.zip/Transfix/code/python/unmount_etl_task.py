import sys, os
from datetime import datetime
sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/shared/prod/code/python')

def main_argparse(logging , args_lst):
    ''' Parse input parameters '''
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config_module", required=True)
    parser.add_argument("-cd", "--config_module_dir", help="Config module FS dir path", required=True)
    parser.add_argument("-cont", "--container", help="container", required=True)
    parser.add_argument("-adls", "--adls_gen2_name", help="adls_gen2_name", required=True)
    args = parser.parse_args(args=args_lst)
    # Print parameters
    for arg in vars(args):
      logging.info("Input param: {} = {}".format(arg, getattr(args, arg)))
    return args


def main(args_lst):
    ''' Main '''
    try:
        import logging
        logging.basicConfig(
                stream=sys.stderr,
                level=logging.INFO,
                format='%(levelname)s %(asctime)s %(funcName)s %(message)s',
                datefmt='%m/%d/%Y %I:%M:%S %p')
        # Turn off not needed logs
        logging.getLogger("py4j").setLevel(logging.ERROR)
        # get parameters
        args = main_argparse(logging, args_lst)
        import utils
        sys.path.append(args.config_module_dir.replace("dbfs:/", '/dbfs/'))
        params = utils.ConfParams.build_from_module(logging, args.config_module, 0, "")
        # Create a spark session
        spark_session = utils.get_spark_session(logging, 'mount_test', 'yarn', params.SPARK_DEFAULT_PARAMS)
        # Unmount dynamic mount point
        dbutils = utils.get_databricks_dbutils(spark_session)
        if "mountPoint='/mnt/do_not_use/{}/{}/transfix'".format(args.adls_gen2_name, args.container) in str(dbutils.fs.mounts()):
          dbutils.fs.unmount(
            mount_point = '/mnt/do_not_use/{}/{}/transfix'.format(args.adls_gen2_name, args.container))
        logging.info("Execution ended")

    except Exception as exception:
        error_desc = "exception: {} at {}".format(type(exception), datetime.now())
        print (error_desc)
        sys.stderr.write(error_desc)
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logging.error(exception)
        sys.stdout.flush()
        sys.exit(1)

if __name__ == "__main__":
    main(sys.argv[1:])
    
