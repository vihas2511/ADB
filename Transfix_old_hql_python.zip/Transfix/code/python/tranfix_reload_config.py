''' Configuration file '''

#### Spark parameters
#SPARK_MASTER = 'local[4]'
SPARK_MASTER = 'yarn'
NUM_EXECUTORS = 8

##### DB connection parameters
HIVE_PARAMETERS = {
    'database': 'ap_transfix_tv_na',
	'dbTransVsbltBw': 'dp_trans_vsblt_bw',
    'dbMasterDataG11': 'dp_masterdata_g11',
    'dbPrdMasterDataG11': 'dp_masterdata_g11',
    'dbOsiNa': 'dp_osi_na_ecc',
    'dbOsiNaUat': 'dp_osi_na_ecc',
    'dbRds': 'rds',
    'dbDirectShpmtCfr': 'dp_direct_shpmt_cfr'
}

###
HIVE_SCRIPT_DIR_PATH="dbfs:/mnt/dppsdatahubx45bab07e/etl/transfix/code/hive"
###
ARCHIVE_DIR_PATH="dbfs:/mnt/do_not_use/dppsdatahubx45bab07e/etl/transfix/archive"

HQLS_ORDERED_LIST = {
        'ds_operational_tariff_filter': 'ds_operational_tariff_filter_calc.hql',
        'tfs_processing': 'tfs_processing.hql',
        'tac_processing': 'tac_processing.hql',
        'ds_accessorial': 'ds_accessorial_calc.hql',
        'ds_subsectorcosts': 'ds_subsectorcosts_calc.hql',
        'ds_tac_detail_pg': 'ds_tac_detail_pg_calc.hql',
        'ds_tac_tender_pg': 'ds_tac_tender_pg_calc.hql'     
}
