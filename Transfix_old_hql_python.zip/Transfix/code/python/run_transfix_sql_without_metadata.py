import sys
sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/shared/prod/code/python')
sys.path.append('/dbfs/mnt/dppsdatahubx45bab07e/etl/transfix/code/python')
import utils
from datetime import datetime


def main_argparse(args_lst):
    ''' Parse input parameters '''
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config_module", required=True)
    parser.add_argument("-s", "--step_no", required=False)
    args = parser.parse_args(args=args_lst)
    return args


def execute_transfix_hive_scripts(logging, spark_session, params, step_no='0'):
    import run_spark_sql as r
    param_dict = params.HIVE_PARAMETERS
    #Get an ordered list of script
    hqls_list = r.get_hqls(spark_session, params.HIVE_SCRIPT_DIR_PATH).collect()
    if step_no == '0':
        for hfile in params.HQLS_ORDERED_LIST.values():
            logging.info("Executing {} script".format(hfile))
            for hscript in hqls_list:
                print("hfile={}".format(hfile))
                print("hscript0={}".format(hscript[0]))
                if hfile in hscript[0]:
                    r.execute_hql_script(logging, spark_session, hscript[1], param_dict)
    else:
        hfile = params.HQLS_ORDERED_LIST[step_no]
        logging.info("Executing {} script".format(hfile))
        for hscript in hqls_list:
            if hfile in hscript[0]:
                r.execute_hql_script(logging, spark_session, hscript[1], param_dict)
                logging.info("Executing {} script has finished".format(hfile))


def main(args_lst):
    ''' Main '''
    try:
        import logging
        #get parameters
        args = main_argparse(args_lst)
        logging.basicConfig(
                stream=sys.stderr,
                level=logging.INFO,
                format='%(levelname)s %(asctime)s %(funcName)s %(message)s',
                datefmt='%m/%d/%Y %I:%M:%S %p')
        logging.info("Input param: config_module = {}".format(args.config_module))
        logging.info("Input param: step_no       = {}".format(args.step_no))
        logging.getLogger("py4j").setLevel(logging.ERROR) 
        #Load config module
        params = utils.ConfParams.build_from_module(
                logging, args.config_module, 0, "")

        #Create a spark session
        spark_session = utils.get_spark_session(
                logging, 'transfix', 'yarn', []
                )
        #spark_session.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
        #spark_session.sql("SET hive.exec.dynamic.partition=true")
        #spark_session.sql("SET hive.exec.dynamic.partition.mode=nonstrict")

        #Execute hive script from HDFS
        execute_transfix_hive_scripts(logging, spark_session, params, args.step_no)
        
        logging.info("execution ended")

    except Exception as exception:
        error_desc = "exception: {} at {}".format(type(exception), datetime.now())
        print (error_desc)
        sys.stderr.write(error_desc)
        print("=" * 80)
        print("exception: {} at {}".format(type(exception), datetime.now()))
        logging.error(exception)
        sys.stdout.flush()
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv[1:])
