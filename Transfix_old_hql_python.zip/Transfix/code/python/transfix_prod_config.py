''' Configuration file '''

# Spark parameters
# SPARK_MASTER = 'local[4]'
SPARK_MASTER = 'yarn'
NUM_EXECUTORS = 8

# DB connection parameters
G11_DB_NAME = "du_masterdata_g11"
RDS_DB_NAME = "rds"
BW_GLOBAL_DB_NAME = "dp_osi_bw_global"
SAP_ASIA_DB_NAME = "dp_osi_ap_ecc"
SAP_EU_DB_NAME = "dp_osi_eu_ecc"
SAP_LA_DB_NAME = "dp_osi_la_ecc"
SAP_NA_DB_NAME = "dp_osi_na_ecc"
SHPMT_CFR_DB_NAME = "dp_direct_shpmt_cfr"
P_OSI_DB_NAME = "dp_osi_{region}"
TRANS_VB_DB_NAME = "dp_trans_vsblt_bw"
TARGET_DB_NAME = "ap_transfix_tv_na"
STAGING_LOCATION = 'dbfs:/mnt/do_not_use/dppsdatahubx45bab07e/etl/transfix/staging'

### Empty archive dir means that we do not archive input excels 
ARCHIVE_DIR_PATH="dbfs:/mnt/do_not_use/dppsdatahubx45bab07e/etl/transfix/archive"

#### TO BE MOVED TO SEPARATE FILE
#### Spark global parameters
SPARK_MASTER = 'yarn'
SPARK_GLOBAL_PARAMS = [
    ('spark.yarn.queue', 'data_load')
]

#### Spark default parameters
SPARK_DEFAULT_PARAMS = [
    ('spark.yarn.queue', 'data_load'),
    ('spark.executor.memory', '5g'),
    ('spark.executor.memoryOverhead', '500m'),
	('spark.sql.broadcastTimeout', "1200000ms")  
]
#### Spark TFX job parameters
SPARK_TFX_PARAMS = [
    ('spark.executor.memory', '20g'),
    ('spark.executor.memoryOverhead', '2g'),
    ('spark.sql.broadcastTimeout', "1200000ms"),
    ('spark.driver.memory', '20g')
]
#### Spark prod job parameters
SPARK_PROD_OTD_PARAMS = [
    ('spark.executor.memory', '50g'),
    ('spark.executor.memoryOverhead', '3g')
]

