#!pip install azure-identity
#!pip install simplejson
# 
# Note: this file has a lot of similarities with this one:
# https://dppsdatahubx45bab07e.blob.core.windows.net/etl/shared/prod/code/python/mdIntegration/md_integration_functions.py
# 
# Differences include:
# 1) No LOGICAL_TABLE_PARTITIONS methods
# 2) Formatting uses 4 spaces for a tab to match the other files
# 3) api_fails is a global variable

import os
import sys
import json
from datetime import datetime
# from . import ps_mdi_transfix_config as transfixconfig
from . import transfix_config as transfixconfig

# Metadata REST API Client
from http import HTTPStatus
from typing import Any, Callable, Dict, List, Union
import requests
from azure.identity import ClientSecretCredential
from simplejson import JSONDecodeError
from functools import lru_cache, wraps
import logging
import time

logger = logging.getLogger("poc PS client")


status_success = "SUCCESS"
status_fail = "FAIL"

def retry_http_request(max_attempts: int = 8, seconds_between_retries: float = 15, increasing_wait_interval_enabled: bool = True):
    """
    This function handles retries for http endpoints.

    With input parameters:

        max_attempts = 5
        seconds_between_retries = 1
        increasing_wait_interval_enabled = True

    Wait times (in seconds) between subsequent retries will be:

        [1, 2, 4, 8]

    Please note that there is no need to wait after last attempt.
    """
    assert max_attempts > 0 and seconds_between_retries > 0

    def is_retry_needed(status_code: int) -> bool:
        status_codes_to_retry = {
            HTTPStatus.REQUEST_TIMEOUT,  # 408
            HTTPStatus.TOO_MANY_REQUESTS,  # 429
            # HTTPStatus.INTERNAL_SERVER_ERROR,  # 500  # client exception is raised in case of 500
            HTTPStatus.BAD_GATEWAY,  # 502
            HTTPStatus.SERVICE_UNAVAILABLE,  # 503
            HTTPStatus.GATEWAY_TIMEOUT,  # 504
        }
        return HTTPStatus(status_code) in status_codes_to_retry

    def get_wait_time(attempt_number: int) -> float:
        assert attempt_number > 0
        if increasing_wait_interval_enabled:
            return seconds_between_retries * pow(2, attempt_number - 1)
        else:
            return seconds_between_retries

    def decorator(func: Callable[..., requests.Response]):
        @wraps(func)
        def wrapper(*args, **kwargs):
            response = None
            for attempt_number in range(1, max_attempts + 1):  # first attempt + retries
                response = func(*args, **kwargs)
                if is_retry_needed(response.status_code):
                    wait_time = get_wait_time(attempt_number=attempt_number)
                    logger.warning(
                        f'Retry needed for http request (attempts so far: {attempt_number}/{max_attempts})'
                        f' # status = {response.status_code}'
                        f' # method = {response.request.method}'
                        f' # url = {response.url}'
                        f' # response = {response.text}'
                    )
                    if attempt_number < max_attempts:  # do not wait if last attempt
                        logger.warning(f'Retry needed for http request, sleeping {wait_time} seconds.')
                        time.sleep(wait_time)
                else:
                    return response

            assert response is not None
            raise Exception(
                " response: ", response, " max_attempts: ", max_attempts, " seconds_between_retries: ", seconds_between_retries
            )

        return wrapper

    return decorator


class BaseRestApiClient:
    DEFAULT_TIMEOUT_SECONDS = 5 * 60

    def __init__(self, tenant_id: str, application_id: str, application_secret: str, metadata_api_application_id: str):
        self._tenant_id = tenant_id
        self._application_id = application_id
        self._application_secret = application_secret
        self._metadata_api_application_id = metadata_api_application_id

    @lru_cache(maxsize=16)
    def _session(self) -> requests.Session:
        session = requests.Session()
        session.auth = self._add_headers_to_request
        return session

    def _add_headers_to_request(self, request: requests.Request) -> requests.Request:
        token_provider = self._token_provider()
        token = token_provider.get_token(self._metadata_api_application_id + '/.default').token
        headers = {
            'Content-type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
        }
        request.headers.update(headers)
        return request

    @lru_cache(maxsize=16)
    def _token_provider(self) -> ClientSecretCredential:
        return ClientSecretCredential(tenant_id=self._tenant_id, client_id=self._application_id, client_secret=self._application_secret)

    @retry_http_request()
    def _send_request(self, method: str, url: str, log_request_execution: bool = True, **request_parameters) -> requests.Response:
        session = self._session()
        response = session.request(
            method=method, url=url, timeout=self.DEFAULT_TIMEOUT_SECONDS, **request_parameters
        )
        is_error_response = self._is_error_response(response=response)
        if log_request_execution:
            log_level = logging.ERROR if is_error_response else logging.DEBUG
            logger.log(
                log_level,
                f'Executed http request:'
                f' # status = {response.status_code}'
                f' # method = {response.request.method}'
                f' # url = {response.url}'
                f' # response = {response.text}'
                f' # body = {(response.request.body or b"null").decode(encoding="utf-8")}',
            )
        if is_error_response:
            raise Exception(response)
        return response

    @classmethod
    def _is_error_response(cls, response: requests.Response) -> bool:
        return response.status_code in {
            HTTPStatus.BAD_REQUEST,  # 400
            HTTPStatus.UNAUTHORIZED,  # 401
            HTTPStatus.FORBIDDEN,  # 403
            HTTPStatus.NOT_FOUND,  # 404
            # HTTPStatus.CONFLICT,  # 409  # needed for semaphore endpoint
            HTTPStatus.INTERNAL_SERVER_ERROR,  # 500
        }

    # TODO: return type is removed to avoid mypy errors (either Dict or List[Dict] is returned depending on endpoint)
    #  idea (as discussed with Maciej Moskala):
    #  return proper namedtuples for each endpoint
    #  these namedtuples will be created using factory function in each type:
    #  def from_response(response: requests.Response) -> ...
    @classmethod
    def _get_json_dict_from_response(cls, response: requests.Response):
        # TODO: this is a simple fix (return empty dict only if response json str is empty)
        #  probably it can be done in a better way - it should be ok for now
        try:
            return response.json()
        except JSONDecodeError as ex:
            if response.text:
                raise Exception(
                    f'Failed to parse response text! (is it correct JSON?)'
                    f'\nresponse text = {response.text}'
                    f'\nurl           = {response.url}',
                    ex,
                )
            else:
                return dict()


### ------------- END OF BASE REST API CLIENT for MetaData --------------------- ###

api_fails = []


def create_low_level_metadata_client():
    low_level_metadata_client = {
        "metadata_api_url": transfixconfig.METADATA_API_URL,
        "tenant_id": transfixconfig.TENANT_ID,
        "application_id": transfixconfig.APPLICATION_ID,
        "application_secret": transfixconfig.APPLICATION_SECRET,
        "metadata_api_application_id": transfixconfig.METADATA_API_APPLICATION_ID
    }

    print("metadata_api_url :", low_level_metadata_client["metadata_api_url"])
    print("tenant_id :", low_level_metadata_client["tenant_id"])
    print("application_id :", low_level_metadata_client["application_id"])
    print("application_secret :", low_level_metadata_client["application_secret"])
    print("metadata_api_application_id :", low_level_metadata_client["metadata_api_application_id"])

    return low_level_metadata_client


def post_process_execution(low_level_metadata_client, my_client, process_name, start_datetime):
    global api_fails
    try:
        ep_response = find_executable_process(
            low_level_metadata_client,
            my_client,
            process_name
        )
        response_dict = json.loads(ep_response.text)
        process_key = response_dict["content"][0]["processKey"]

        response = my_client._send_request(
            method="post",
            url=low_level_metadata_client["metadata_api_url"] + '/api/v1/processExecutions', 
            log_request_execution=True,
            json={
                "processKey": process_key,
                "parentProcessRunKey": None,
                "processStatus": "EXECUTING",
                "processType": "EXECUTABLE",
                "startDatetime": start_datetime
            },
        )
        print("post /api/v1/processExecutions response: {}".format(response.text))
        response_dict = json.loads(response.text)
        process_run_key = response_dict["processRunKey"]
        print("post_process_execution process_run_key: {}".format(process_run_key))

        return process_run_key

    except Exception as e:
        print("exception: post /api/v1/processExecutions: {}".format(e))
        api_fails.append(["exception: post /api/v1/processExecutions, processKey = {}, exception: {}".format(process_key, e)])


def find_executable_process(low_level_metadata_client, my_client, process_name):
    global api_fails
    try:
        response = my_client._send_request(
            method="get",
            url=low_level_metadata_client["metadata_api_url"] + '/api/v1/executable',
            log_request_execution=True,
            params={
                "processNameExact": process_name
            },
        )
        print("get /api/v1/executable by processNameExact response: {}".format(response.text))
        print("process_key: {}".format(json.loads(response.text)["content"][0]["processKey"]))
        return response
    except Exception as e:
        print("exception: get /api/v1/executable , exception: {}".format(e))
        api_fails.append(["exception: get /api/v1/executable, processName = {}, exception: {}".format(process_name, e)])


def get_physical_table_key(low_level_metadata_client, my_client, table_path):
    global api_fails
    try:
        response = my_client._send_request(
            method="get",
            url=low_level_metadata_client["metadata_api_url"] + '/api/v1/datasets/physical', 
            log_request_execution=True,
            params={
                'objectName': table_path,
                'objectTypeCode': "PHYSICAL_TABLE"
            },
        )
        print("get /api/v1/datasets/physical table response: {}".format(response.text))
        response_dict = json.loads(response.text)
        object_key = 0
        for i in response_dict["content"]:
            if i["objectName"] == table_path:
                object_key = i["objectKey"]
                print("Found Physical Table: ", i["objectName"], "with Object Key: ", i["objectKey"])
        assert object_key != 0
        return object_key
    except Exception as e:
        print("exception : get /api/v1/datasets/physical , exception: {}".format(e))
        api_fails.append(["exception: get /api/v1/datasets/physical, table_path = {}, exception: {}".format(table_path, e)])


def post_dataset_physical_partition(low_level_metadata_client, my_client, process_run_key, infra_id, table_path, dataset, partition): 
    
    global api_fails

    print("debug: post physical partition for table name: {}, partition: {}".format(dataset, partition))
    
    table_path = table_path + dataset
 
    try:
        object_key = get_physical_table_key(low_level_metadata_client, my_client, table_path)
        response = my_client._send_request(
            method="post",
            url=low_level_metadata_client["metadata_api_url"] + "/api/v1/datasets/physical", 
            log_request_execution=True,
            json={
                "objectTypeCode": "PHYSICAL_TABLE_PARTITION",
                "defaultParentPhysicalObjectKey": object_key,
                'objectName': table_path,
                'objectDescription': infra_id + table_path,
                "fileTypeCode": "parquet",
                "statusCode": "STAGING",
                "dataProviderCode": "Product Supply",
                "dataTypeCode": "PS",
                "owningApplicationName": transfixconfig.OWNING_DL_APP_NM,
                "infrastructureKey": transfixconfig.CONTAINER_ID, # 1486,
                "partitionDefinitionValue": table_path,
                "objectSizeInKb": None,
                "processRunKey": process_run_key,
                "secureGroupKey": 0
            }
        )
        print("### PHYSICAL_TABLE_PARTITION")
        print("post /api/v1/datasets/physical partition response: {}".format(response.text))
        response_dict = json.loads(response.text)
        print("### PHYSICAL_TABLE_PARTITION response dictionary")
        print(response_dict)
        pp_object_key = response_dict["objectKey"]
        print("physical partition object key: {}".format(pp_object_key))
        return pp_object_key
    except Exception as e:
        print("exception : post /api/v1/datasets/physical , exception: {}".format(e))
        api_fails.append(["exception: post /api/v1/datasets/physical, objectName = {}, exception: {}".format(table_path, e)])

def get_logical_table_key(LowLevelMetadataClient, my_client, table_name):
  try:
    # GET /api/v1/datasets/logical
    response=my_client._send_request(
      method="get",
      url=LowLevelMetadataClient["metadata_api_url"] + '/api/v1/datasets/logical', 
      log_request_execution= True,
      params={
          'objectName': table_name.lower(),
          'objectTypeCode' : "LOGICAL_TABLE"
      },
    )
    print("get /api/v1/datasets/logical table response: {}".format(response.text))
    response_dict = json.loads(response.text)
    object_key = 0
    for i in response_dict["content"]:
      if i["objectName"].lower() == table_name.lower():
        object_key = i["objectKey"]
        print("Found Logical Table: ", i["objectName"], "with Object Key: ", i["objectKey"])
    assert object_key != 0
    return object_key
  except Exception as e:
    print("exception detected in: get /api/v1/datasets/logical, table: {}, exception: {}".format(table_name.lower(), e))
    api_fails.append(["exception: get /api/v1/datasets/logical, table_name = {}, status = {}".format(table_name.lower(), status_fail)])
    
    
def get_logical_table_partition_key(LowLevelMetadataClient, my_client, table_partition_path):
  try:
    # GET /api/v1/datasets/logical
    response=my_client._send_request(
      method="get",
      url=LowLevelMetadataClient["metadata_api_url"] + '/api/v1/datasets/logical', 
      log_request_execution= True,
      params={
          'objectName': table_partition_path,
          'objectTypeCode' : "LOGICAL_TABLE_PARTITION"
      },
    )
    print("get /api/v1/datasets/logical table partition response: {}".format(response.text))
    response_dict = json.loads(response.text)
    object_key = 0
    for i in response_dict["content"]:
      if i["objectName"].lower() == table_partition_path.lower():
        object_key = i["objectKey"]
        print("Found Logical Table Partition: ", i["objectName"], "with Object Key: ", i["objectKey"])
    #assert object_key != 0
    return object_key
  except Exception as e:
    print("exception detected in: get /api/v1/datasets/logical, table partition: {}, exception: {}".format(table_partition_path, e))
    api_fails.append(["exception: get /api/v1/datasets/logical, table_partition_name = {}, status = {}".format(table_partition_path, status_fail)])
  
  
  
def post_dataset_logical_partition(LowLevelMetadataClient, my_client, infra_id, table_path, dataset, partition):
  """ POST /api/v1/datasets/logical
  WARNING: Cannot re-write logical partitions. All previous partitions created with the same objectName have to be set to ARCHIVE or DELETED statusCode"""
  print("debug: post logical partition for table name: {}, partition: {}".format(dataset, partition))
  table_logical_prt_name = transfixconfig.DB_NAME + '/' + dataset.lower() + partition
  logical_table_name = transfixconfig.DB_NAME + '/' + dataset.lower() + '/'
  table_path = table_path + dataset
  print("table_path = {}, partition = {}".format(table_path, partition))
  try:
    object_key=get_logical_table_key(LowLevelMetadataClient, my_client, logical_table_name)
    lp_object_key = ''
    lp_object_key = get_logical_table_partition_key(LowLevelMetadataClient, my_client, table_logical_prt_name)
    if not lp_object_key or lp_object_key == 0:
      response=my_client._send_request(
        method="post",
        url=LowLevelMetadataClient["metadata_api_url"] + "/api/v1/datasets/logical", 
        log_request_execution=True,
        json={
          "objectTypeCode": "LOGICAL_TABLE_PARTITION",  # logical partition object_type_key = 13
          "defaultParentObjectKey": object_key,
          'objectName': table_logical_prt_name,
          'objectDescription': infra_id + table_path + partition,
          "statusCode": "STAGING",
          "dataProviderCode": "Product Supply",  # name=PIPO - Global,code=PIPO_GLOBAL  # name=IOPT,code=NULL
          "dataTypeCode": "PS",
          "owningApplicationName": transfixconfig.OWNING_DL_APP_NM,
          "secureGroupKey": 0  #int. 0 in PS cases
          }
        )
      print("post /api/v1/datasets/logical partition response: {}".format(response.text))
      # get partition key
      response_dict = json.loads(response.text)
      lp_object_key=response_dict["objectKey"]
      print("logical partition object key: {}".format(lp_object_key))
      return lp_object_key
    else:
        print("Existing logical partition object key: {}".format(lp_object_key))
        return lp_object_key
  except Exception as e:
    print("exception detected in: post /api/v1/datasets/logical partition = {}, exception: {}".format(table_path, e))
    api_fails.append(["exception: post, /api/v1/datasets/logical, objectName = {}, status = {}, exception: {}".format(table_path, status_fail, e)])
    
    
def assoc_logical_physical_partitions_by_key(LowLevelMetadataClient, my_client, logical_partition_key, physical_partition_key):
  try:
    response=my_client._send_request(
      method="post",
      url=LowLevelMetadataClient["metadata_api_url"] + "/api/v1/object-assocs", 
      log_request_execution=True,
      json={
        "objectAKey": logical_partition_key,
        "objectAssocType": "LP_2_PP",
        "objectBKey": physical_partition_key
        },
    )
    print("assoc logical-physical partitions by key response: {}".format(response.text))
  except Exception as e:
    print("exception response: post, /api/v1/objects/assoc {}".format(e))
    api_fails.append(["exception: post, /api/v1/objects/assoc, logical_partition_key = {} physical_partition_key = {} error = {}".format(logical_partition_key, physical_partition_key, str(e))])



def publish_execution_to_metadata(process_run_key, api_fails):
    try:
        low_level_metadata_client = create_low_level_metadata_client()
        my_client = BaseRestApiClient(
            low_level_metadata_client["tenant_id"],
            low_level_metadata_client["application_id"],
            low_level_metadata_client["application_secret"],
            low_level_metadata_client["metadata_api_application_id"]
        )
        # If function is called from outside with a list of api fails 
        # provided by the caller this api_fails variable is different 
        # from the one used by other functions here
        if not api_fails:
            print("no fails: starting successful publish. process_run_key: {}".format(process_run_key))
            # publish -- successfully completed process run
            response = my_client._send_request(
                method="post",
                url=low_level_metadata_client["metadata_api_url"] + "/api/v1/datasets/physical/publication", 
                log_request_execution=True,
                json={
                    'processRunKey': process_run_key,
                    'processRunStatusCode': "COMPLETED",
                    'publishEventIndicator': True,
                }
            )
            print("post /api/v1/datasets/physical/publication response: {} (ProcessRunKey -> processRunStatusCode = COMPLETED)".format(response.text))
            print("SUCCESS published")
        else:
            print("fails in metadata api found: starting process failure recording")
            print(api_fails)
            print()
            # do not publish -- record failed API publication
            # From execution, get start time and process key.
            response = my_client._send_request(
                method="get",
                url=low_level_metadata_client["metadata_api_url"] + "/api/v1/processExecutions", 
                log_request_execution=True,
                params={
                    "processRunKey": process_run_key
                }
            )
            print("response get /api/v1/processExecutions: {}".format(response.text))
            print("failed response status code: {}".format(response.status_code))
            response_dict = json.loads(response.text)
            process_key = response_dict["content"][0]["item"]["processKey"]
            print("failed process key: {}".format(process_key))
            start_datetime = response_dict["content"][0]["item"]["startDatetime"]
            print("failed start datetime: {}".format(start_datetime))

            end_datetime = datetime.utcnow().isoformat()
            response = my_client._send_request(
                method="put",
                url=low_level_metadata_client["metadata_api_url"] + "/api/v1/processExecutions", 
                log_request_execution=True,
                json={
                    "processRunKey": process_run_key,
                    "processKey": process_key,
                    "parentProcessRunKey": None,
                    "processStatus": "FAILED",
                    "processType": "EXECUTABLE",
                    "startDatetime": start_datetime,
                    "endDatetime": end_datetime
                }
            )
            print("FAILURE recorded \nPut /api/v1/processExecutions for failed publication response: {}".format(response.text))
    except Exception as e:
        print("Exception in publish_execution_to_metadata(), process_run_key = {}, exception: {}".format(process_run_key, e))
        api_fails.append(["exception in publish_execution_to_metadata(), process_run_key = {}, {}".format(process_run_key, e)])


def cdl_metadata_start_execution(process_name, common_tblnms_str, infra_id, table_path, dataset, partition):
    global api_fails
    try:
        low_level_metadata_client = create_low_level_metadata_client()
        my_client = BaseRestApiClient(
            low_level_metadata_client["tenant_id"],
            low_level_metadata_client["application_id"],
            low_level_metadata_client["application_secret"],
            low_level_metadata_client["metadata_api_application_id"]
        )
        # In scope tables
        if common_tblnms_str in dataset or common_tblnms_str == '': # see transvisibility 
            
            process_run_key = post_process_execution(low_level_metadata_client, my_client, process_name, start_datetime=datetime.utcnow().isoformat())
            
            logical_partition_key = post_dataset_logical_partition(low_level_metadata_client, my_client, infra_id, table_path, dataset, partition)
                        
            physical_partition_key = post_dataset_physical_partition(low_level_metadata_client, my_client, process_run_key, infra_id, table_path, dataset, partition)
            
            assoc_logical_physical_partitions_by_key(low_level_metadata_client, my_client, logical_partition_key, physical_partition_key)
            
            return process_run_key, api_fails
        else:
            api_fails.append(["Error: Table failed to validate: {}".format(dataset)])
            print("Error: Table failed to validate {}.".format(dataset))
            return 0, api_fails

    except Exception as exception:
        error_desc = "exception starting metadata execution: {} at {}".format(exception, datetime.now())
        print(error_desc)
        api_fails.append(["exception starting metadata execution: {}".format(exception)])
        return 0, api_fails
