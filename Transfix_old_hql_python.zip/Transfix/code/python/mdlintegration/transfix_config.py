import json

from pyspark.sql.session import SparkSession
spark = SparkSession.builder.getOrCreate()
if spark.conf.get("spark.databricks.service.client.enabled") == "true":
    from pyspark.dbutils import DBUtils
    dbutils = DBUtils(spark)
else:
    import IPython
    dbutils = IPython.get_ipython().user_ns["dbutils"]

# WORKSPACE_PROD = '6168179505272179'
WORKSPACE_ID = 'PROD'
#WORKSPACE_ID = 'BF'

if WORKSPACE_ID == 'BF':

    METADATA_API_APPLICATION_ID = '361895e1-6d30-4784-9153-c03ed47dc0d5'
    METADATA_API_URL            = 'https://cdl-turbine-np03.pg.com'
    APPLICATION_ID              = 'ba8f9da4-559f-4045-80b2-c6de6bc36584'
    OWNING_APP_KEY              = 236
    OWNING_DL_APP_NM            = 'Product Supply - Transfix Light Refined'
    DATADELIVERY_API_URL        = 'https://APIM-NonProd.pgcloud.com'
    KEY_VAULT_SCOPE             = 'kv-productsupply-n203' # 'kv-psdatahub-p201'
    SECRET                      = 'Az-App-CDL-ProductSupply'
    CONTAINER_ID                = 1486
    CONTAINER_URL               = 'https://dppsdatahubx45bab07e.blob.core.windows.net/lightrefined'
    TABLE_PATH_PREFIX           = "/transfix/prod/final/"
    DB_NAME                     = 'ad_transfix_tv_na'  

elif WORKSPACE_ID == 'PROD':

    METADATA_API_APPLICATION_ID = '361895e1-6d30-4784-9153-c03ed47dc0d5' 
    METADATA_API_URL            = 'https://api.pgcloud.com/othersupportingdata/it/v1/metadata' #Old PROD: 'https://cdl-turbine.pg.com'             
    APPLICATION_ID              = 'ba8f9da4-559f-4045-80b2-c6de6bc36584' 
    DATADELIVERY_API_URL        = 'https://APIM-NonProd.pgcloud.com'                   
    OWNING_APP_KEY              = 372
    OWNING_DL_APP_NM            = 'Product Supply - Transfix Light Refined'
    KEY_VAULT_SCOPE             = 'kv-psdatahub-p201'
    SECRET                      = 'Az-App-CDL-ProductSupply'  #Az-App-CDL-ProductSupply-BF
    CONTAINER_ID                = 1524 
    CONTAINER_URL               = 'https://dppsdatahubx45bab07e.blob.core.windows.net/lightrefined'
    TABLE_PATH_PREFIX           = "/transfix/prod/final/"
    DB_NAME                     = 'ap_transfix_tv_na'

else:
  raise ValueError('Wrong WORKSPACE_ID')


TENANT_ID          = '3596192b-fdf5-4e2c-a6fa-acb706c963d8'
APPLICATION_SECRET = dbutils.secrets.get(KEY_VAULT_SCOPE, SECRET)
